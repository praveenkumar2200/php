<?php
include('config.php');
session_start();
$userid=$_SESSION["ID"];
$user=$_SESSION["username"];
if(isset($_GET["pst_id"])&& $_GET['pst_id'] !== '')
	{
	$pst_id=$_GET["pst_id"];
	$like_status='';
	$like_sql="SELECT * FROM post_likes where post_id='$pst_id' && user_id='$userid'";
	$like_result=mysqli_query($con,$like_sql);
	$like_row=mysqli_fetch_array($like_result);
    if($like_row)
    {
		$like_status=$like_row["status"];
        if($like_status==1)
		{
			$like_status=0;
			$like_src="images/unlike.png";
		}
		else
		{
			$like_status=1;
			$like_src="images/like.png";
		}
		$like1_sql="update post_likes set status='$like_status' where post_id='$pst_id' && user_id='$userid'";
	    $like1_result=mysqli_query($con,$like1_sql);
		header("location:usertimeline.php");
		exit;
	    //$like1_row=mysqli_fetch_array($like1_result);
	}
	else
	{

	    $like_status=1;
		$like2_sql="insert into post_likes(status,post_id,user_id) values('$like_status','$pst_id','$userid')";
	    $like2_result=mysqli_query($con,$like2_sql);
	    //$like2_row=mysqli_fetch_array($like2_result);
		if($like2_result)
		{
			 
			$like_src="images/like.png";
			header("location:usertimeline.php");
		exit;
		}
	}

    }	
	?>