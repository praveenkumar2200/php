<?php
session_start();
include("config.php");
echo $userid=$_SESSION["ID"];
$user=$_SESSION["username"];
if(isset($_GET["cmnt_id"])&& $_GET['cmnt_id'] !== '')
{
	echo $cmntid=$_GET["cmnt_id"];
	echo $postid=$_POST['pid1'];
	echo $desc=$_POST['desc1'];
	//echo $post_userid=$_POST['uid1'];
	$sql="insert into comment_reply(description,post_id,cmnt_id,reply_userid) values('$desc','$postid','$cmntid','$userid')";
	$result=mysqli_query($con,$sql);
	if($result)
	{
		echo "Reply posted Successfully";
	}
}
?> 


