<?php
$id=10;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Timeline</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <link href="http://netdna.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css" rel="stylesheet">

</head>

<body>
    <form method='post' action=''>
        <input type='text' placeholder='Enter username' name='txt_uname' id='txt_uname'>
        <br/>
        <input type='text' placeholder='Enter First name' name='txt_fname' id='txt_fname'>
        <br/>
        <input type='text' placeholder='Enter Last name' name='txt_lname' id='txt_lname'>
        <br/>
        <input type='text' placeholder='Enter email' name='txt_email' id='txt_email'>
        <br/>
        <input type='submit' value='Submit' id='submit' name='submit' onclick="doSomething(<?php echo $id;?>)">
    </form>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <!--  <script type="text/javascript">
	$(document).ready(function(){

  $("#submit").click(function(){
    var username = $("#txt_uname").val();
    var fname = $("#txt_fname").val();
    var lname = $("#txt_lname").val();
    var email = $("#txt_email").val();
 
    $.ajax({
       url:'saveDatapage.php',
       type:'post',
       data:{username:username,fname:fname,lname:lname,email:email},
       success:function(response){
          location.reload(); // reloading page
       }
    });
 
  });
});
    </script>-->
	<script>
	function doSomething(id){
		 var username = $("#txt_uname").val();
         var fname = $("#txt_fname").val();
		var lname = $("#txt_lname").val();
		var email = $("#txt_email").val();
 
    $.ajax({
       url:'saveDatapage.php?post='+id+'',
       type:'post',
       data:{username:username,fname:fname,lname:lname,email:email},
       success:function(response){
          location.reload(); // reloading page
       }
    });
	}
	</script>
</body>

</html>