<?php 
if(isset($_POST["submit_button"]))
{
	echo $txt=$_POST["input_tag"];
	if($txt==1)
	{
		echo 1;
	echo "<script>swal('Title','Your message');</script>";	
	}
	elseif($txt==2)
	{
			echo 2;
    echo "<script>b();</script>";
	}
	else
	{
			echo "rest";
		echo "<script>c();</script>";
	}
}
?>

<html>
<head>
 <link href="sweetalert.css" type="text/css" rel="stylesheet">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
 <script src="sweetalert.min.js" type="text/javascript"></script>
</head>
<body>
  <form action="" method="post">
    <input type="text"name="input_tag" />

    <input type="submit" name="submit_button" 
           value="Click here"/>

    </form>
	<script>
	function a(){
	swal("Title","Your message");
	};
	</script>
	<script>
	function b(){
	swal({
  title: "Title",
  text: "Your message",
  timer: 2000
  });
};
	</script>
	<script>
	function c(){
	swal({ 
    title: "Title", 
    text: "Your message", 
    type: "success" 
});
	};
	</script>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
<style>
.my-tool-tip {
  color: black;
}
</style>
</head>
<body>

<p id="input">Click on the button to copy the text from the text field. Try to paste the text (e.g. ctrl+v) afterwards in a different window, to see the 
effect.</p>

<input type="text" value="Hello World" id="myInput">
<button onclick="myFunction()">Copy text</button>

<div id="div1" >Text To Copy </div>
<textarea placeholder="Press ctrl+v to Paste the copied text" rows="5" cols="20"></textarea>
<button id="button1" onclick="CopyToClipboard('input')">Click to copy</button>
<div id="a" onclick="copyDivToClipboard()"> Click to copy 12</div>

<a href="" onclick="copyDivToClipboard('postText')" id='copy-button' class='my-tool-tip' data-toggle="tooltip" data-placement="bottom" title="Copy to Clipboard">Copy Text
												<i class="fa fa-copy" style="font-size:14px;margin-left:25px;"></i>
												</a>
            <script>
                function copyDivToClipboard() {
                    var range = document.createRange();
                    range.selectNode(document.getElementById("a"));
                    window.getSelection().removeAllRanges(); // clear current selection
                    window.getSelection().addRange(range); // to select text
                    document.execCommand("copy");
                    window.getSelection().removeAllRanges();// to deselect
					
                }
            </script>
<script>
function CopyToClipboard(containerid) {
if (document.selection) { 
    var range = document.body.createTextRange();
    range.moveToElementText(document.getElementById(containerid));
    range.select().createTextRange();
    document.execCommand("copy"); 

} else if (window.getSelection) {
    var range = document.createRange();
     range.selectNode(document.getElementById(containerid));
     window.getSelection().addRange(range);
     document.execCommand("copy");
     alert("text copied") 
}}
</script>
<script>
function myFunction() {
  var copyText = document.getElementById("myInput");
  copyText.select();
  copyText.setSelectionRange(0, 99999)
  document.execCommand("copy");
  alert("Copied the text: " + copyText.value);
}
</script>
 <script>
			($("a.my-tool-tip").tooltip();
			$("#copy-button").on('click', function(e) {
	
			var tooltip = $(this);
			tooltip.attr('data-original-title', 'Copied!');
			$("a.my-tool-tip").tooltip('show');
			//e.preventDefault();
			});
            </script>
</body>
</html>