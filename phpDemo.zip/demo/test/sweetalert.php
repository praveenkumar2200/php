
<?php 
if(isset($_POST["submit_button"]))
{
	echo $txt=$_POST["input_tag"];
	if($txt==1)
	{
		echo 1;
	echo "<script>swal('Title','Your message');</script>";	
	}
	elseif($txt==2)
	{
			echo 2;
    echo "<script>b();</script>";
	}
	else
	{
			echo "rest";
		echo "<script>c();</script>";
	}
}
?>

<!DOCTYPE html>
<html>

<head>
  <link data-require="sweet-alert@*" data-semver="0.4.2" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" />
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
   <script src="jquery-3.4.1.min.js" type="text/javascript"></script>
</head>

<body>
  <form id="from1">
    <input type='button' value='Alert with title' id='but2'>
    <button>Save</button>
  </form>

  <script>
    document.querySelector('#from1').addEventListener('submit', function(e) {
      var form = this;
      
      e.preventDefault();
      
      swal({
          title: "Are you sure?",
          text: "You will not be able to recover this imaginary file!",
          icon: "warning",
          buttons: [
            'No, cancel it!',
            'Yes, I am sure!'
          ],
          dangerMode: true,
        }).then(function(isConfirm) {
          if (isConfirm) {
            swal({
              title: 'Shortlisted!',
              text: 'Candidates are successfully shortlisted!',
              icon: 'success'
            }).then(function() {
              form.submit();
            });
          } else {
            swal("Cancelled", "Your imaginary file is safe :)", "error");
          }
        });
    });
  </script>
  <script>
    $( document ).ready(function() {

        // Message
        $("#but2").click(function(){
            
      swal({
          title: "Are you sure?",
          text: "You will not be able to recover this imaginary file!",
          icon: "warning",
          buttons: [
            'No, cancel it!',
            'Yes, I am sure!'
          ],
          dangerMode: true,
        })
        });
		   });
  </script>
  
  <style>
    .swal-button--confirm {
      background-color: #DD6B55;
    }
  </style>
</body>

</html>