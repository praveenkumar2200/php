<?php 
include 'config.php'; // Database connection
$pst_id=$_GET["post"];
$uname = $_POST['username'];
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
if(!empty($uname)&&!empty($email))
{
$insert_query = "INSERT INTO 
                 users(username,fname,lname,email) 
                 VALUES('".$uname."','".$fname."','".$pst_id."','".$email."')";
mysqli_query($con,$insert_query);
echo 1;
}
?>