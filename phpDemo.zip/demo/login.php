<?php
session_start();
include('config.php');
if(isset($_SESSION["loggedin"]))
{
	header("location:home.php");
	exit;
}else{
	
	



if(isset($_POST["login"]))
{
	$user=$pass="";
	$user_err=$pass_err="";
	$user=trim($_POST["username"]);
	if(!empty($user)&&!empty(trim($_POST["psw"])))
	{
		$sql="select * from users where username='$user'";
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($result);
		if($row["username"]==$user)
		{
			$pass=trim($_POST["psw"]);
			$hash_pass=$row["password"];
			if(password_verify($pass,$hash_pass))
			{
				 session_start();
				$_SESSION["loggedin"]=true;
				$_SESSION["username"]=$row["username"];
				$_SESSION["ID"]=$row["id"];
				header("location:home.php");
			}
			else
			{
				$pass_err="Invalid Password";
			}
		}
		else
		{
			$user_err="No Account found with this username";
		}
	}
	else
	{
		echo "Oops! Something went wrong.Try again later. "; 
	}
}
}
?>


<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
form {border: 3px solid #f1f1f1;}

input[type=text], input[type=password] {
  /*width: 100%;*/
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0px 0px 146px;
  border: none;
  cursor: pointer;
 
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
</head>
<body style="width:500px;margin: 100px 189px 50px 449px;">
<div>
<h2>Login Form</h2>

<form action="" method="post">
 

  <div class="container">
    <label for="uname" style="margin-right:65px;"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="username" required></br>
	<span style="color:red;margin-left:148px;"><?php if(isset($user_err)){ echo $user_err;} ?> </span></br>

    <label for="psw" style="margin-right:65px;"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required></br>
	<span style="color:red;margin-left:148px;"><?php if(isset($pass_err)){ echo $pass_err;} ?> </span></br>
      
    <button type="submit" name="login">Login</button></br>
    <label>
      Not registered yet! &nbsp <a href="Registration.php">Register</a>
    </label>
  </div>

  
</form>
</div>
</body>
</html>
