<?php 

include('image.php');
//current date and time

//$datee = new DateTime("now", new DateTimeZone('Asia/Kolkata'));
//echo  $datee->format("Y-m-d h:i:s");
//$int=$datee->getTimestamp();


$userid=$_SESSION["ID"];
$user=$_SESSION["username"];

$sql1="select * from users where id='$userid' ";
$result1=mysqli_query($con,$sql1);
$row=mysqli_fetch_array($result1);

echo $userimage=$row["created_at"];
echo "<br>";


$s = $userimage;
$dt = new DateTime($s);

echo $date = $dt->format('d/m/Y');echo "<br>";
echo $time = $dt->format('H:i');echo "<br>";




date_default_timezone_set("Asia/Calcutta");
echo $dd= date('Y-m-d H:i:s', time()); echo "<br>";

$date1 = strtotime($userimage); 
$date2 = strtotime($dd); 

//calculate yesterday
 $date = date('d/m/Y', strtotime("2020-01-19 23:59:00"));
if($date == date('d/m/Y',$date2 - (24 * 60 * 60))) {
    echo   $date = 'Yesterday';
}
else 
{
	echo "not";
}

//end
$diff = abs($date2 - $date1); 


 
$years = floor($diff / (365*60*60*24)); 



$months = floor(($diff - $years * 365*60*60*24) 
							/ (30*60*60*24)); 



$days = floor(($diff - $years * 365*60*60*24 - 
			$months*30*60*60*24)/ (60*60*24)); 


 
$hours = floor(($diff - $years * 365*60*60*24 
	- $months*30*60*60*24 - $days*60*60*24) 
								/ (60*60)); 



$minutes = floor(($diff - $years * 365*60*60*24 
		- $months*30*60*60*24 - $days*60*60*24 
						- $hours*60*60)/ 60); 



$seconds = floor(($diff - $years * 365*60*60*24 
		- $months*30*60*60*24 - $days*60*60*24 
				- $hours*60*60 - $minutes*60)); 

// Print the result 
printf("%d years, %d months, %d days, %d hours, "
	. "%d minutes, %d seconds", $years, $months, 
			$days, $hours, $minutes, $seconds); 
?> 
