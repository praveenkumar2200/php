<?php

include('image.php');

$userid=$_SESSION["ID"];
$user=$_SESSION["username"];

$sql1="select * from images where userid='$userid' ";
$result1=mysqli_query($con,$sql1);
$row=mysqli_fetch_array($result1);
$userimage=$row["name"];
if(isset($userimage))
{
	  $img_src="profile/". $user ."/".$userimage;
}
else
{
	$img_src='upload/user.png';
}

if (isset($_GET['file_id']))
{
	$id = $_GET['file_id'];
	 $filepath = 'profile/'.$user."/" . $userimage;

    if (file_exists($filepath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=' . basename($filepath));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize('profile/'.$user."/" . $userimage));
        readfile('profile/'.$user."/" . $userimage);

        // Now update downloads count
        //$newCount = $file['downloads'] + 1;
        //$updateQuery = "UPDATE files SET downloads=$newCount WHERE id=$id";
       // mysqli_query($con,$updateQuery);
        exit;
    }
}

if (isset($_POST['post'])) 
{
	
    if (!empty(trim($_POST['userpost'])) || isset($_FILES['upload']['name']) && !empty($_FILES['upload']['name']))
	{
        $post_err = $user_Post = "";
        $user_Post = trim($_POST["userpost"]);

        if (isset($_FILES['upload']['name']) && !empty($_FILES['upload']['name']))
		{
            $ext = strtolower(pathinfo($_FILES['upload']['name'], PATHINFO_EXTENSION));
			$name = pathinfo($_FILES['upload']['name'], PATHINFO_FILENAME)."_".$userid."_".date('YmdHms'). ".".$ext;  
            $allow_ext = array('jpg', 'jpeg', 'png', 'gif');
            if (in_array($ext, $allow_ext)) 
			{                              
                if (!file_exists("posts/".$user."/"))
                {
                    mkdir("posts/".$user."/", 0700, true);                      
                }
                $target = "posts/".$user."/".$name;  
            }
			else 
			{
                echo "Invalid Image Format";
            }
        } 
		else 
		{
            $name = "";
        }

        $post_Sql = "insert into timeline(text,imagename,userid) values('$user_Post','$name','$userid')";
        $post_Result = mysqli_query($con, $post_Sql);
        if ($post_Result) 
		{
			move_uploaded_file($_FILES['upload']['tmp_name'], $target);
           
        }
    }
	else 
	{
        echo "Please Enter Something";
    }
}

?>



<!DOCTYPE html>
    <html lang="en">
		<head>
            <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
            <title>Home</title>
            <style>
                body {
                    /*margin-top: 20px;*/
                    background: #eee;
                }
                
                .divider {
                    height: 20px;
                    display: block;
                }
                /* ========================================================================
                 * FORM MISC
                 * ======================================================================== */
                
                .input-group-addon {
                    -moz-border-radius: 0px;
                    -webkit-border-radius: 0px;
                    border-radius: 0px;
                    min-width: 39px;
                }
                
                .input-group-addon .ckbox,
                .input-group-addon .rdio {
                    position: absolute;
                    top: 4px;
                    left: 10px;
                }
                
                .input-group-lg > .form-control,
                .input-group-lg > .input-group-addon,
                .input-group-lg > .input-group-btn > .btn,
                .input-group-sm > .form-control,
                .input-group-sm > .input-group-addon,
                .input-group-sm > .input-group-btn > .btn,
                .input-group-xs > .form-control,
                .input-group-xs > .input-group-addon,
                .input-group-xs > .input-group-btn > .btn {
                    -moz-border-radius: 0px;
                    -webkit-border-radius: 0px;
                    border-radius: 0px;
                }
                
                .input-sm,
                .form-group-sm .form-control {
                    -moz-border-radius: 0px;
                    -webkit-border-radius: 0px;
                    border-radius: 0px;
                }
                
                .form-control {
                    -moz-border-radius: 0px;
                    -webkit-border-radius: 0px;
                    border-radius: 0px;
                    -moz-box-shadow: none;
                    -webkit-box-shadow: none;
                    box-shadow: none;
                }
                
                @media (max-width: 640px) {
                    .form-inner-all [class*="col-"]:last-child .form-control {
                        margin-top: 15px;
                    }
                }
                /* ========================================================================
				* PROFILE
				* ======================================================================== */
                
                .profile-cover {
                    width: 100%;
                }
                
                .profile-cover .cover {
                    position: relative;
                    border: 10px solid #FFF;
                }
                
                .profile-cover .cover .inner-cover {
                    overflow: hidden;
                    height: auto;
                }
                
                .profile-cover .cover .inner-cover img {
                    border: 1px solid transparent;
                    text-align: center;
                    width: 100%;
                }
                
                .profile-cover .cover .inner-cover .cover-menu-mobile {
                    position: absolute;
                    top: 10px;
                    right: 10px;
                }
                
                .profile-cover .cover .inner-cover .cover-menu-mobile button i {
                    font-size: 17px;
                }
                
                .profile-cover .cover ul.cover-menu {
                    padding-left: 150px;
                    position: absolute;
                    overflow: hidden;
                    left: 1px;
                    float: left;
                    bottom: 0px;
                    width: 100%;
                    margin: 0px;
                    background: none repeat scroll 0% 0% rgba(0, 0, 0, 0.24);
                }
                
                .profile-cover .cover ul.cover-menu li {
                    display: block;
                    float: left;
                    margin-right: 0px;
                    padding: 0px 10px;
                    line-height: 40px;
                    height: 40px;
                    -moz-transition: all 0.3s;
                    -o-transition: all 0.3s;
                    -webkit-transition: all 0.3s;
                    transition: all 0.3s;
                }
                
                .profile-cover .cover ul.cover-menu li:hover {
                    background-color: rgba(0, 0, 0, 0.44);
                }
                
                .profile-cover .cover ul.cover-menu li.active {
                    background-color: rgba(0, 0, 0, 0.64);
                }
                
                .profile-cover .cover ul.cover-menu li a {
                    color: #FFF;
                    font-weight: bold;
                    display: block;
                    height: 40px;
                    line-height: 40px;
                    text-decoration: none;
                }
                
                .profile-cover .cover ul.cover-menu li a i {
                    font-size: 18px;
                }
                
                .profile-cover .profile-body {
                    margin: 0px auto 10px;
                    position: relative;
                }
                
                .profile-cover .profile-timeline {
                    padding: 15px;
                }
                
                .img-post {
                    width: 30px;
                    height: 30px;
                }
                
                .img-post2 {
                    width: 50px;
                    height: 50px;
                }
                
                <!--- css---> .panel-body {
                    background: #fff;
                }
                
                .cover-photo {
                    position: relative;
                }
                
                a:hover {
                    text-decoration: none;
                }
                
                .fb-timeline-img img {
                    width: 100%;
                    border-radius: 4px 4px 0 0;
                    -webkit-border-radius: 4px 4px 0 0;
                }
                
                .profile-thumb img {
                    width: 140px;
                    height: 140px;
                    border-radius: 50%;
                    -webkit-border-radius: 50%;
                    margin-top: -90px;
                    border: 3px solid #fff;
                }
                
                .profile-info .panel-footer ul li a {
                    color: #7a7a7a;
                }
                
                .profile-thumb {
                    float: left;
                    position: relative;
                }
                
                .p-text-area,
                .p-text-area:focus {
                    border: none;
                    font-weight: 300;
                    box-shadow: none;
                    color: #c3c3c3;
                    font-size: 16px;
                }
                
                .fb-user-mail {
                    margin: 10px 0 0 20px;
                    display: inline-block;
                }
                
                .fb-name {
                    bottom: 5px;
                    left: 175px;
                    position: absolute;
                }
                
                .fb-name h2 a {
                    color: #FFFFFF;
                    text-rendering: optimizelegibility;
                    text-shadow: 0 0 3px rgba(0, 0, 0, 0.8);
                    font-size: 25px;
                }
                
                .fb-user-thumb {
                    float: left;
                    /*width: 70px;*/
                    margin-right: 15px;
                }
                
                .fb-user-thumb img {
                    width: 50px;
                    height: 50px;
                    border-radius: 50%;
                    -webkit-border-radius: 50%;
                }
                
                .fb-user-details h3 {
                    margin: 5px 0 0;
                    font-size: 18px;
                    font-weight: 300;
                }
                
                .fb-user-details p {
                    color: #c3c3c3;
                }
                
                .fb-user-status {
                    padding: 10px 0;
                    line-height: 20px;
                }
                
                .fb-time-action {
                    padding: 5px 0;
                }
                
                .fb-cmt {
                    padding: 12px 0px 8px 12px;
                }
                
                .fb-border {
                    border-top: 1px solid #ebeef5;
                }
                
                .fb-time-action span,
                .fb-time-action a {
                    margin-right: 5px;
                }
                
                .fb-time-action a {
                    color: #2972a1;
                }
                
                .fb-time-action a:hover {
                    text-decoration: underline;
                }
                
                .fb-time-action span {
                    color: #5a5a5a;
                }
                
                .fb-status-container,
                .fb-comments li {
                    /* margin: 0 -15px 0 -15px;*/
                    padding: 0 15px;
                }
                
                .fb-gray-bg {
                    background: #f6f6f6;
                }
                
                .fb-comments li {
                    border-top: 1px solid #ebeef5;
                    padding: 3px;
                }
                
                .fb-comments .cmt-thumb {
                    width: 50px;
                    float: left;
                    margin-right: 15px;
                }
                
                .fb-comments .cmt-thumb img {
                    width: 40px;
                    height: 40px;
                    border-radius: 50%;
                }
                
                .fb-comments .cmt-details {
                    padding-top: 5px;
                }
                
                .fb-comments .cmt-details a {
                    font-size: 14px;
                    font-weight: bold;
                }
                
                .fb-comments .cmt-details a.like-link {
                    font-size: 12px;
                    font-weight: normal;
                }
                
                .cmt-form {
                    display: inline-block;
                    width: 90%;
                }
                
                .cmt-form textarea {
                    height: 50px;
                    line-height: 35px;
                }
                
                .fb-timeliner h2 {
                    background: #828283;
                    color: #fff;
                    margin-top: 0;
                    padding: 10px 15px;
                    font-size: 16px;
                    border-radius: 4px;
                    -webkit-border-radius: 4px;
                    font-weight: 300;
                }
                
                .fb-timeliner ul {
                    margin-left: 15px;
                    margin-bottom: 20px;
                    list-style-type: none;
                }
                
                .fb-comments {
                    list-style-type: none;
                }
                
                .fb-timeliner ul li {
                    margin-bottom: 3px;
                }
                
                .fb-timeliner ul li a {
                    color: #999797;
                    border-left: 4px solid #d3d7dd;
                    padding-left: 10px;
                    padding-top: 3px;
                    padding-bottom: 3px;
                    display: block;
                }
                
                .fb-timeliner ul li a:hover {
                    color: #999797;
                    border-left: 4px solid #b1b1b1;
                    padding-left: 10px;
                }
                
                .fb-timeliner ul li.active a {
                    color: #7a7a7a;
                    border-left: 4px solid #7a7a7a;
                    padding-left: 10px;
                }
                
                .recent-highlight {
                    background: #FF6C60 !important;
                }
                
                .user-cmt {
                    margin: 4px;
                    display: inline-block;
                    width: 60%;
                    height: 45px;
                    line-height: 35px;
                    padding: 10px;
                }
				
				.user-cmnt-reply{
					background: white;
					width: 200px;
					margin-left: 54px;
					border-radius:10px;
					margin-left:31px;
					margin-top:-31px;
					padding:0px 12px;
				}
				.user-cmnt-img{
					border-radius:50%;
					height:27px;
					width:27px !important;
				}
                .user-cmnt-detail{
					background: white;
					width: 180px;
					margin-left: 54px;
					border-radius:10px;
				}
                <!-- popup css---> #myImg {
                    border-radius: 5px;
                    cursor: pointer;
                    transition: 0.3s;
                }
                
                #myImg:hover {
                    opacity: 0.7;
                }
                /* The Modal (background) */
                
                .modal {
                    margin-top: 50px;
                    display: none;
                    /* Hidden by default */
                    position: fixed;
                    /* Stay in place */
                    z-index: 1;
                    /* Sit on top */
                    padding-top: 100px;
                    /* Location of the box */
                    left: 0;
                    top: 0;
                    width: 100%;
                    /* Full width */
                    height: 100%;
                    /* Full height */
                    overflow: auto;
                    /* Enable scroll if needed */
                    background-color: rgb(0, 0, 0);
                    /* Fallback color */
                    background-color: rgba(0, 0, 0, 0.7);
                    /* Black w/ opacity */
                }
                /* Modal Content (image) */
                
                .modal-content {
                    margin: auto;
                    display: block;
                    width: 80%;
                    max-width: 500px;
                }
                /* Caption of Modal Image */
                
                #caption {
                    margin: auto;
                    display: block;
                    width: 80%;
                    max-width: 700px;
                    text-align: center;
                    color: #ccc;
                    padding: 10px 0;
                    height: 150px;
                }
                /* Add Animation */
                
                .modal-content,
                #caption {
                    -webkit-animation-name: zoom;
                    -webkit-animation-duration: 0.6s;
                    animation-name: zoom;
                    animation-duration: 0.6s;
                }
                
                @-webkit-keyframes zoom {
                    from {
                        -webkit-transform: scale(0)
                    }
                    to {
                        -webkit-transform: scale(1)
                    }
                }
                
                @keyframes zoom {
                    from {
                        transform: scale(0)
                    }
                    to {
                        transform: scale(1)
                    }
                }
                /* The Close Button */
                
                .close1 {
                    position: absolute;
                    top: 15px;
                    right: 35px;
                    color: #f1f1f1;
                    font-size: 40px;
                    font-weight: bold;
                    transition: 0.3s;
                }
                
                .close1:hover,
                .close1:focus {
                    color: red;
                    text-decoration: none;
                    cursor: pointer;
                }
                /* 100% Image Width on Smaller Screens */
                
                @media only screen and (max-width: 700px) {
                    .modal-content {
                        width: 100%;
                    }
                }
                
             
            </style>
			<style>
				.showLeft{
                   // background-color: #0d77b6 !important;
                   // border:1px solid #0d77b6 !important;
                    text-shadow: none !important;
                    color:#fff !important;
                    padding:0px 2px 0px 2px;
                }

                .icons li {
                    background: none repeat scroll 0 0 #337ab7;
                    height: 5px;
                    width: 5px;
                    line-height: 0;
                    list-style: none outside none;
                    margin-right: 0px;
                    margin-top: 3px;
                    vertical-align: top;
                    border-radius:50%;
                    pointer-events: none;
                }
				.dropbtn {
				  //background-color: #3498DB;
				  color: black;
				  //padding: 16px;
				  font-size: 16px;
				  border: none;
				  cursor: pointer;
				}

				.dropbtn:hover, .dropbtn:focus {
				  background-color: white;
				}

				.dropdown {
				  position: relative;
				  display: inline-block;
				}

				.dropdown-content {
					padding:10px;
				  display: none;
				  position: absolute;
				  background-color: #f1f1f1;
				  min-width: 140px;
				  overflow: auto;
				  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
				  z-index: 1;
				}

				.dropdown-content a {
				  color: #66757f;;
				  padding: 3px 6px;
				  text-decoration: none;
				  display: block;
				}

				.dropdown a:hover {background-color: #ddd;}

				.show {display: block;}
			</style>
			<style>
			.more-menu-caret {
				position: absolute;
				top: -11px;
				left: 15px;
				width: 18px;
				height: 10px;
				float: left;
				overflow: hidden;
			}

			.more-menu-caret-outer,
			.more-menu-caret-inner {
				position: absolute;
				display: inline-block;
				margin-left: -1px;
				font-size: 0;
				line-height: 1;
			}

			.more-menu-caret-outer {
				border-bottom: 10px solid #c1d0da;
				border-left: 10px solid transparent;
				border-right: 10px solid transparent;
				height: auto;
				left: 0;
				top: 0;
				width: auto;    
			}

			.more-menu-caret-inner {
				top: 1px;
				left: 1px;
				border-left: 9px solid transparent;
				border-right: 9px solid transparent;
				border-bottom: 9px solid #fff;
			}

			.my-tool-tip {
			  color: black;
			}
			</style>


        </head>

        <body>
            <div class="container bootstrap snippets">
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-4">
                        <div class="panel rounded shadow">
                            <div class="panel-body">
                                <div class="inner-all">
                                    <ul class="list-unstyled">
                                        <li class="text-center">
                                            <img data-no-retina="" class="img-circle img-bordered-primary" src="<?php echo $img_src; ?>" alt="<?php echo $user; ?>" height="200px" width="200px">
                                        </li>
                                        <li class="text-center">
                                            <h4 class="text-capitalize"><?php echo $user; ?></h4>
                                            <p class="text-muted text-capitalize">web designer</p>
                                        </li>
                                        <li>
                                            <a href="" class="btn btn-success text-center btn-block">PRO Account</a>
                                        </li>
                                        <li>
                                            <br>
                                        </li>
                                        <li>
                                            <div class="btn-group-vertical btn-block">
                                                <a href="userprofile.php" class="btn btn-default"><i class="fa fa-cog pull-right"></i>Edit Account</a>
												 <a href="addfriend.php" class="btn btn-default"><i class="fas fa-user-check pull-right"></i>Friends</a>
												 <a href="changepassword.php" class="btn btn-default"><i class="fa fa-lock pull-right" ></i>Change Password</a>
												<!--<a href="receiverequest.php" class="btn btn-default"><i class="fa fa-user-plus pull-right"></i>Friend Requests</a>-->
                                                <a href="logout.php" class="btn btn-default"><i class="fa fa-sign-out pull-right"></i>Logout</a>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- /.panel -->

                        <div class="panel panel-theme rounded shadow">
                            <div class="panel-heading">
                                <div class="pull-left">
                                    <h3 class="panel-title">Contact</h3>
                                </div>
                                <div class="pull-right">
                                    <a href="#" class="btn btn-sm btn-success"><i class="fa fa-facebook"></i></a>
                                    <a href="#" class="btn btn-sm btn-success"><i class="fa fa-twitter"></i></a>
                                    <a href="#" class="btn btn-sm btn-success"><i class="fa fa-google-plus"></i></a>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <!-- /.panel-heading -->
                            <div class="panel-body no-padding rounded">
                                <ul class="list-group no-margin">
                                    <li class="list-group-item"><i class="fa fa-envelope mr-5"></i> support@bootdey.com</li>
                                    <li class="list-group-item"><i class="fa fa-globe mr-5"></i> www.bootdey.com</li>
                                    <li class="list-group-item"><i class="fa fa-phone mr-5"></i> +6281 903 xxx xxx</li>
                                </ul>
                            </div>
                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->

                    </div>
                    <div class="col-lg-9 col-md-9 col-sm-8">

                        <div class="panel rounded shadow">
                            <form action="..." id="likeForm">
                                <textarea class="form-control input-lg no-border" rows="2" placeholder="What are you doing?..." id="myPost"></textarea>
                            </form>
                            <div class="panel-footer">
                                <!-- <button class="btn btn-success pull-right mt-5">POST</button>-->
                                <ul class="nav nav-pills">
                                    <li><a href="#"><i class="fa fa-user fa-2x"></i></a></li>
                                    <li><a href="#"><i class="fa fa-map-marker fa-2x"></i></a></li>
                                    <li><a href="#"><i class="fa fa-camera fa-2x"></i></a></li>
                                    <li><a href="#"><i class="fa fa-smile-o fa-2x"></i></a></li>
                                </ul>
                                <!-- /.nav nav-pills -->
                            </div>
                            <!-- /.panel-footer -->
                        </div>
                        <!-- /.panel -->
                        <div class="">
                            <?php
								$userid=$_SESSION["ID"];
                                $user=$_SESSION["username"];

								//===All users post====
								
								//$posted_sql="select u.id, u.username,u.firstname,u.lastname,t.id,t.text,t.imagename, t.createdat,i.name from users as u RIGHT outer  join timeline as t on u.id=t.userid left outer join images as i on t.userid=i.userid order by t.createdat DESC ";
                                $posted_sql="select u.id, u.username,u.firstname,u.lastname,t.id as post_id,t.userid,t.text,t.imagename, t.createdat,i.name from users as u RIGHT outer  join timeline as t on u.id=t.userid left outer join images as i on t.userid=i.userid where t.id not in(SELECT post_id FROM `blocked_post` WHERE status=1 and blockby_userid='$userid') order by t.createdat DESC";
								$posted_result=mysqli_query($con,$posted_sql);
                                $count=0;
                                while($data=mysqli_fetch_array($posted_result))
                                {
								$post_id=$data["post_id"];
							    $post_id;
							    $post_userid=$data["userid"];
                                $user_name=$data["username"];
								if(!empty($data["firstname"]))
								{
									 $name=$data["firstname"]." ".$data["lastname"];
								}
								else
								{
									$name=$data["username"];
								}
								$text=$data["text"];
								$posted_image=$data["imagename"];
							    $created_at=$data["createdat"];
								$profile_img=$data["name"];
								$profile_src="profile/".$user_name."/".$profile_img;
								$post_src="posts/".$user_name."/".$posted_image;
							    $count++;
								// calculate date and time 
								
								date_default_timezone_set("Asia/Calcutta");
                                $current_date= date('Y-m-d H:i:s', time()); 
							    $post_date = new DateTime($created_at);
                                $date = $post_date->format('d M, Y');
                                $time = $post_date->format('h:i A');
								
								$date1 = strtotime($created_at); 
                                $date2 = strtotime($current_date); 
                                $diff = abs($date2 - $date1); 
                                $years = floor($diff / (365*60*60*24)); 
                                $months = floor(($diff - $years * 365*60*60*24)/(30*60*60*24)); 
								$days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24)); 
								$hours = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24)/(60*60)); 
								$minutes = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60)/ 60); 
                                $seconds = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60 - $minutes*60)); 
                                
								// Print the result
                                //echo "<br>";								
                               // printf("%d years, %d months, %d days, %d hours, ". "%d minutes, %d seconds", $years, $months, $days, $hours, $minutes, $seconds); 
			                   // echo "<br>";
			                    if($days!=0)
			                    { 
							        $date = date('d/m/Y', strtotime($created_at));
                                    if($date == date('d/m/Y',$date2 - (24 * 60 * 60))) 
									{										
										 $posted_date= "Yesterday at ".$time;
									}
									else 
									{
										$date = $post_date->format('d M, Y'); 
			                            $posted_date= $date." at ".$time;
									}
			                        
			                    }
			                    elseif($hours!=0)
			                    {
			                     	$posted_date= $hours." hours ago.";
			                    }
			                    elseif($minutes!=0)
			                    {
			                       $posted_date= $minutes." mins ago.";
		                     	}
								else
								{
									 $posted_date= " Just now.";
								}
							?>
                                <div class="panel" id="hide">
                                    <div class="panel-body">
                                        <div class="fb-user-thumb">
                                            <img src="<?php echo $profile_src;?>" alt="" />
                                        </div>
                                        <div class="fb-user-details">
                                            <h3><a href="#" class="#"><?php echo $name;?></a></h3>
                                            <p style="font-size:11px;">
                                                <?php echo $posted_date; ?>
                                            </p>
                                        </div>
										<div class="fb-user-thumb" style="float: right;margin-top: -5%;">

                                            <div class="dropdown">
											<ul class="dropbtn icons showLeft" onclick="myFunction(<?php echo $post_id;?>)">
												<li></li>
												<li></li>
												<li></li>
											</ul>
											<div id="myDropdown<?php echo $post_id;?>" class="dropdown-content">
												<a href=""  onclick="hidePost(<?php echo $post_id; ?>,<?php echo $post_userid; ?>)">Hide Post<i class="fa fa-remove" style="font-size:14px;margin-left: 27px;"></i></a>	
												<a href="" onclick="copyDivToClipboard('postText<?php echo $post_id; ?>');return false;" id='copy-button' class='my-tool-tip' data-toggle="tooltip" data-placement="bottom" title="Copy to Clipboard">Copy Text
												<i class="fa fa-copy" style="font-size:14px;margin-left:21px;"></i>
												</a>
												<a href="#">Delete Post<i class="fa fa-trash" style="font-size:14px;margin-left: 16px;"></i></a>
												<a href="#">Share Post<i class="fa fa-share-alt" style="font-size:14px;margin-left: 18px;"></i></a>
											</div>
											</div>
                                        </div>
                                        <div class="clearfix"></div>
                                        <input type="hidden" value="<?php echo $post_id; ?>">
                                        <p id="postText<?php echo $post_id; ?>" class="fb-user-status fb-border" style="padding:15px 0px 0px 20px;">
                                            <?php echo $text; ?>
                                        </p>
                                        <img src="<?php echo $post_src; ?>" alt="" class="img-responsive full-width" style="padding: 15px 20px;">
										<div class="fb-status-container fb-border">
											<?php

												//-------comment counts--------
												$count_sql="select COUNT(*) as cmt_count from comment where post_id='$post_id'";
												$count_result=mysqli_query($con,$count_sql);
												$count_row=mysqli_fetch_array($count_result);
												if($count_row)
												{
													$cmt_count=$count_row['cmt_count'];
												}

												//------ check like status---------
												//echo $post_id;
												//echo $userid;
												$like_sql="SELECT * FROM post_likes where post_id='$post_id' && user_id='$userid'";
												$like_result=mysqli_query($con,$like_sql);
												$like_row=mysqli_fetch_array($like_result);
												if($like_row)
												{
													$like_status=$like_row["status"];
													if($like_status==1)
													{
														$like_src="images/like.png";
													}
													else
													{
														$like_src="images/unlike.png";
													}
												}
												else
												{
													$like_src="images/unlike.png";
												}

												 //------ check like count---------

												$countlike_sql="select COUNT(*) as like_count from post_likes where status=1 && post_id='$post_id'";
												$countlike_result=mysqli_query($con,$countlike_sql);
												$countlike_row=mysqli_fetch_array($countlike_result);
												if($countlike_row)
												{
													$like_count=$countlike_row["like_count"];

												}

												$likers_sql="select u.id,u.username,p.post_id, p.created from users as u right outer JOIN post_likes as p on u.id=p.user_id where p.post_id='$post_id' && status!=0 order by p.created desc";
												$likers_result=mysqli_query($con,$likers_sql);
												$likers_row=mysqli_fetch_array($likers_result);

											//echo $data2=$likers_row[1][0];
											?>
											<div class="fb-time-action fb-cmt">
												<p style="font-size:25px;color:#337ab7;float:left;margin-right:10px;">
													<?php echo $like_count; ?>
												</p>
												<!--<a href="usertimeline.php?pst_id=<?php echo $post_id; ?>" class="like" style="border:none;background-color:white;">-->
												<input type="image" class="likepost" onclick="likeUnlike(<?php echo $post_id;?>)" src="<?php echo $like_src; ?>" alt="Submit" width="65" height="30"/>
												<!--</a>
												<!--<a href="#" title="Like this">Like</a>-->
												<input type="image" src="images/cmt.png" alt="Submit" width="40" height="30" style=";float:right;">
												<span style=";float:right;font-size:20px;color:#337ab7;"><?php echo $cmt_count; ?></span>
												<input type="image" src="images/share.png" alt="Submit" width="35" height="27" style="float:right;margin-right:50px">
												<span style="font-size:20px;color:#337ab7;float:right;"></span>
											</div>
                                        </div>

                                        <div class="fb-status-container fb-border fb-gray-bg">
                                            <div class="fb-time-action like-info">
                                                <a href="#"></a>
                                                <?php

												if($like_count==1)
												{
													echo  "<a href='#'>". $name1=$likers_row[1] ."</a>";
													echo "<span> like this</span>";
												}
												elseif($like_count>1)
												{
													echo  "<a href='#'>". $name1=$likers_row[1] ."</a>";
													echo "<span>and</span>";
													echo  "<a href='#'>".$like_count= ($like_count-1)." ". "others</a>";
													echo "<span> like this</span>";		
												}
												else
												{
													echo "<span>Be the first to like this</span>";	
												}

												?>

                                            </div>

                                            <ul class="fb-comments">
												<?php

													$sql_cmt="select u.id, u.username,c.cmt_id,c.post_id,c.cmt,c.user_id,c.create_at,i.name from users as u RIGHT outer join comment as c on u.id=c.user_id left outer join images as i on u.id=i.userid where c.post_id='$post_id' order by c.create_at limit 2";
													$result_cmt=mysqli_query($con,$sql_cmt);
													$cmt_count=0;
													while($row_cmt=mysqli_fetch_array($result_cmt))
													{
														$cmt_count=$cmt_count+1;
														$cmt_userid=$row_cmt["user_id"];
														$cmt_postid=$row_cmt["post_id"];
														$cmt_cmtid=$row_cmt["cmt_id"];
														$cmt_username=$row_cmt["username"];
														$cmt=$row_cmt["cmt"];
														$user_profile=$row_cmt["name"];
														$cmt_at=$row_cmt["create_at"];
														$src_profile="profile/".$cmt_username."/".$user_profile;

														date_default_timezone_set("Asia/Calcutta");
														$current_date= date('Y-m-d H:i:s', time()); 
														$cmt_date = new DateTime($cmt_at);
														$date = $cmt_date->format('d M, Y');
														$time = $cmt_date->format('h:i A');
								
														$date1 = strtotime($cmt_at); 
														$date2 = strtotime($current_date); 
														$diff = abs($date2 - $date1); 
														$years = floor($diff / (365*60*60*24)); 
														$months = floor(($diff - $years * 365*60*60*24)/(30*60*60*24)); 
														$days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24)); 
														$hours = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24)/(60*60)); 
														$minutes = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60)/ 60); 
														$seconds = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60 - $minutes*60)); 
													
														// Print the result
														//echo "<br>";								
														// printf("%d years, %d months, %d days, %d hours, ". "%d minutes, %d seconds", $years, $months, $days, $hours, $minutes, $seconds); 
														// echo "<br>";
														if($days!=0)
														{ 
															$date = date('d/m/Y', strtotime($cmt_at));
															if($date == date('d/m/Y',$date2 - (24 * 60 * 60))) 
															{										
																$cmt_date= "Yesterday at ".$time;
															}
															else 
															{
																$date = $cmt_date->format('d M, Y'); 
																$cmt_date= $date." at ".$time;
															}
														
														}
														elseif($hours!=0)
														{
															$cmt_date= $hours." hours ago.";
														}
														elseif($minutes!=0)
														{
															$cmt_date= $minutes." mins ago.";
														}
														else
														{
														 $cmt_date= " Just now.";
														}
												?>
                                                <li>
                                                <a href="#" class="cmt-thumb">  <img src="<?php echo $src_profile; ?>" alt=""></a>
                                                <div class="cmt-details">
													<div  class="user-cmnt-detail">
                                                        <a href="#"><?php echo $cmt_username; ?> </a>
                                                        <span> <?php echo $cmt; ?></span>
                                                        <p style="color:#c3c3c3;font-size: 11px;"><?php echo $cmt_date; ?></p>
													</div>
													<!--comment reply-->
																
													<div style="margin:-10px 0px 0px 65px">
														<a href="" class="like-link" id="show-hidden-menu" onclick="replyDiv(<?php echo $cmt_cmtid;?>);return false;">Reply</a> 
														<div class="hidden-menu<?php echo $cmt_cmtid;?>" style="display: none;">
															<?php
																$reply_sql="select u.id, u.username,c.rep_id,c.post_id,c.description,c.reply_userid,c.createdat,i.name from users as u RIGHT outer join comment_reply as c on u.id=c.reply_userid left outer join images as i on u.id=i.userid where c.cmnt_id='$cmt_cmtid'  order by c.createdat limit 3";
																$reply_result=mysqli_query($con,$reply_sql);
																while($rply_row=mysqli_fetch_array($reply_result))
																{
																	$rply_id=$rply_row["rep_id"];
																	$desc=$rply_row["description"];
																	$reply_userid=$rply_row["reply_userid"];
																	$rply_at=$rply_row["createdat"];
																	$rply_postid=$rply_row["post_id"];
																	$uname=$rply_row["username"];
																	$reply_userimg=$src_profile="profile/".$uname."/".$rply_row["name"];
																		
															?>
															<img class="user-cmnt-img" src="<?php echo $reply_userimg;?>" alt=""/>
															<div class="cmt-details">
																<div class="user-cmnt-reply">
																	<a href="#"><?php echo $uname; ?></a>
																	<span> <?php echo $desc; ?></span>
																	<p style="color:#c3c3c3;font-size: 11px;"><?php echo $rply_at; ?><!-- - <a href="#" class="like-link">Like</a>--></p>
																</div>
															</div>
															<?php
																}
															?>																	
															<img src="<?php echo $img_src;?>" alt="" style="border-radius:50%;height:27px;width:27px !important"/>
															<form id="replyForm" name="form" style="display:inline;">
															<input  type="text" placeholder="Write a reply...." id="cmntreply<?php echo $cmt_cmtid;?>" name="cmntreply" style="border-radius:50px;padding: 0px 10px;">
															<button  class="btn-success" style="border-radius:50px;padding: 0px 8px;" onclick="reply(<?php echo $cmt_cmtid;?>,<?php echo $cmt_postid;?>)" >Reply</button>
															</form>
														</div>		
													</div>
                                                </div>
                                                </li>
                                                <?php
													}
												?>
                                            </ul>
                                        </div>
                                        <div class="fb-border fb-time-action">
                                            <div class="fb-user-thumb" style="margin-left:80px;">
                                                <img src="<?php echo $img_src;?>" alt="" />
                                            </div>
                                            <div class="fb-user-details">
                                                <form  id="cmntForm" name="form">
													<!-- <input class="user-cmt" type="text" name="comment" placeholder="Write a comment..." id="comment" />-->
													<input class="user-cmt" id="name<?php echo $post_id;?>" type="text" placeholder="Write a comment..." name="name">
                                                    <button type="submit" class="btn btn-lg btn-success" name="post_cmt" id="comment" onclick="postComment('<?php echo $post_id;?>')">Post</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php
								}
							?>
                        </div>
                    </div>
                </div>
            </div>

            <div id="postModal" class="modal">
                <span class="close1">&times;</span>
                <form class="modal-content animate" action="" method="post" enctype='multipart/form-data'>
                    <div class="container">
                        <div style="width:41%;">
                            <div class="panel rounded shadow">
                                <textarea class="form-control input-lg no-border" rows="2" placeholder="What are you doing?..." name="userpost"></textarea>

                                <div class="panel-footer">
                                    <ul class="nav nav-pills">
                                        <li><a href="#"><i class="fa fa-user fa-2x"></i></a></li>
                                        <li><a href="#"><i class="fa fa-map-marker fa-2x"></i></a></li>
                                        <li><a href="#"><i class="fa fa-camera fa-2x" id="icon1"></i></a></li>
                                        <input type="file" name="upload" id="imgupload" style="display:none;">
                                        <li><a href="#"><i class="fa fa-smile-o fa-2x"></i></a></li>
                                    </ul>
                                    <!-- /.nav nav-pills -->
                                </div>
                                <!-- /.panel-footer -->
                            </div>
                        </div>
                        <div style="margin-left: 10%;">
                            <div id="image-holder"> </div>
                        </div>
                        </br>
                        <span style="color:red;margin-left: 12%;"><?php if(isset($img_err)){ echo $img_err;} ?> </span>
                        <div class="clearfix" style="margin:25px 114px">
                            <button type="button" onclick="document.getElementById('postModal').style.display='none'" class="btn btn-lg">Cancel</button>
                            <button type="submit" class="btn btn-lg btn-success" name="post">Post</button>
                        </div>
                    </div>
                </form>
                <div id="caption"></div>
            </div>
        </body>

        <script>
            // Get the modal
            var modal = document.getElementById("postModal");

            // Get the image and insert it inside the modal - use its "alt" text as a caption
            var txt = document.getElementById("myPost");
            var modalImg = document.getElementById("img01");
            var captionText = document.getElementById("caption");
            txt.onclick = function() {
                modal.style.display = "block";
                modalImg.src = this.src;
                captionText.innerHTML = this.alt;
            }

            // Get the <span> element that closes the modal
            var span = document.getElementsByClassName("close1")[0];

            // When the user clicks on <span> (x), close the modal
            span.onclick = function() {
                modal.style.display = "none";
            }
        </script>

        <script>
            $('#icon1').click(function() {
                $('#imgupload').trigger('click');
            });

            $("#imgupload").on('change', function() {

                if (typeof(FileReader) != "undefined") {

                    var image_holder = $("#image-holder");
                    image_holder.empty();

                    var reader = new FileReader();
                    reader.onload = function(e) {
                        $("<img />", {
                            "src": e.target.result,
                            "class": "thumb-image"
                        }).appendTo(image_holder);

                    }
                    image_holder.show();
                    reader.readAsDataURL($(this)[0].files[0]);
                } else {
                    alert("This browser does not support FileReader.");
                }
            });
        </script>
		
		 <!--  script for comments on post -->    
		<script>
			function postComment(pstid){
			var name = $("#name"+pstid).val();	
			$.post("comments.php?post_id="+pstid+"", {
			name1: name,
			}, function(data) {
				alert(data);
				$('#cmntForm')[0].reset(); 
				location.reload();// To reset form fields
				});
			}
		</script>		

		 <!--  script for like on post -->    
		<script>
		function likeUnlike(pstid){
		$.post("likeunlike.php?pst_id="+pstid+"", {
			
		}, function(data) {

		//alert(data);
		$('#likeForm')[0].reset(); // To reset form fields
		location.reload();
		});

		}
		</script>
 
		<script>
		/* When the user clicks on the button, 
		toggle between hiding and showing the dropdown content */
		function myFunction(id) {
			//alert(id);
		  document.getElementById("myDropdown"+id).classList.toggle("show");
		}

		// Close the dropdown if the user clicks outside of it
		window.onclick = function(event) {
		  if (!event.target.matches('.dropbtn')) {
			var dropdowns = document.getElementsByClassName("dropdown-content");
			var i;
			for (i = 0; i < dropdowns.length; i++) {
			  var openDropdown = dropdowns[i];
			  if (openDropdown.classList.contains('show')) {
				openDropdown.classList.remove('show');
			  }
			}
		  }
		}
		</script>
		 
        <script>
            function copyDivToClipboard(containerid) {
            var range = document.createRange();
            range.selectNode(document.getElementById(containerid));
            window.getSelection().removeAllRanges(); // clear current selection
            window.getSelection().addRange(range); // to select text
            document.execCommand("copy");
            window.getSelection().removeAllRanges();// to deselect
			return false;
            }
        </script>
        <script>
			$("a.my-tool-tip").tooltip();
			$("#copy-button").on('click', function(e) {
	       
			var tooltip = $(this);
			tooltip.attr('data-original-title', 'Copied!');
			$("a.my-tool-tip").tooltip('show');
			e.preventDefault();
			});
            </script>
            <script>
			function hidePost(postid,post_userid){
				
		        $.post("hidepost.php?post_id="+postid+"",{
			     post_userid1:post_userid
		       },function(data){
				 alert(data);
			   $("#cancelForm")[0].reset();
			  $('#hide').load('usertimeline.php');
			   //location.reload();
		      });
	        }
				
			
            </script>
			<script>
			function replyDiv(id){
				 $('.hidden-menu'+id).slideToggle("fast");
				 //location.reload():
			}
            </script>
			<script>
			
			function reply(cmnnt_id,pid){
				var desc = $("#cmntreply"+cmnnt_id).val();	
				//var uid = $("#uid"+cmnnt_id).val();
				$.post("commentreply.php?cmnt_id="+cmnnt_id+"", {
				desc1: desc,
				pid1: pid,
				
				}, function(data) {

				alert(data);
				$('#replyForm')[0].reset(); 
				location.reload();// To reset form fields
				});

			}
			</script>
			
    </html>