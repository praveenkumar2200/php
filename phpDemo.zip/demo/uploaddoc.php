<?php
include('image.php');
 $userid=$_SESSION["ID"];
$user=$_SESSION["username"];
// Uploads files
if (isset($_POST['save'])) { // if save button on the form is clicked
    // name of the uploaded file
  if(isset($_FILES['myfile']['name'])&&!empty($_FILES['myfile']['name']))
   {
   // $filename = $_FILES['myfile']['name'];
    
	$extension=pathinfo($_FILES['myfile']['name'],PATHINFO_EXTENSION);
    $filename=pathinfo($_FILES['myfile']['name'],PATHINFO_FILENAME)."_".date('YmdHms').".".$extension;
    // destination of the file on the server
	if(!file_exists("uploads/".$user))
	{
		mkdir("uploads/".$user,0700,true);
	}
    $destination = 'uploads/'.$user ."/". $filename;

    // get the file extension
   // $extension = pathinfo($filename, PATHINFO_EXTENSION);
    
	
    // the physical file on a temporary uploads directory on the server
    $file = $_FILES['myfile']['tmp_name'];
    $size = $_FILES['myfile']['size'];

    if (!in_array($extension, ['zip', 'pdf', 'docx'])) {
        echo "You file extension must be .zip, .pdf or .docx";
    } elseif ($_FILES['myfile']['size'] > 1000000) { // file shouldn't be larger than 1Megabyte
        echo "File too large!";
    } else {
        // move the uploaded (temporary) file to the specified destination
        if (move_uploaded_file($file, $destination)) {
            $sql = "INSERT INTO files (name,uploadedby,size, downloads) VALUES ('$filename',$userid, $size, 0)";
            if (mysqli_query($con, $sql)) {
                echo "File uploaded successfully";
            }
        } else {
            echo "Failed to upload file.";
        }
    }
   }
   else
   {
		echo "No file selected";
   }
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="stylesheet" href="style.css">
    <title>Files Upload and Download</title>
	<style>
	.bk_img
	{
		background-image: url("images/wall.jpg");
		background-repeat: no-repeat;
		 background-size: cover;
	}
	form {
 background-image: url("images/blue.jpg");
  width: 35%;
  margin: 100px auto;
  padding: 30px;
  border: 1px solid #555;
}
input {
  width: 100%;
  border: 1px solid #f1e1e1;
  display: block;
  padding: 5px 10px;
}
button {
  border: none;
  padding: 10px;
  border-radius: 5px;
}
table {
  width: 60%;
  border-collapse: collapse;
  margin: 100px auto;
}
th,
td {
  height: 50px;
  vertical-align: center;
  border: 1px solid black;
}
</style>
  </head>
  <body class="bk_img"">
    <div class="container">
      <div class="row">
        <form action="" method="post" enctype="multipart/form-data" >
          <h3>Upload File</h3>
          <input type="file" name="myfile"> <br>
          <button type="submit" name="save">upload</button>
        </form>
      </div>
    </div>
  </body>
</html>