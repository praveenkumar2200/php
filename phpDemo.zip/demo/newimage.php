
<?php
//session_start();
include('image.php');
/*include('config.php');
if(!isset($_SESSION["loggedin"])||$_SESSION["loggedin"]!=true)
{
	header("location:login.php");
	exit;
}*/
$userid=$_SESSION["ID"];
$user=$_SESSION["username"];

$sql1="select * from images where userid=$userid ";
$result1=mysqli_query($con,$sql1);
$row=mysqli_fetch_array($result1);

$userimage=$row["image"];
//echo "upload/".$userimage."_".$userid."_".current_time();
if(isset($userimage))
{
	 $img_src=$userimage;
}
else
{
	$img_src='upload/user.png';
}


if(isset($_POST["upload"]))
{
	if(isset($_FILES['userimg']['name'])&&!empty($_FILES['userimg']['name']))
	{
		$name=$_FILES['userimg']['name'];
		//$target1 = "upload/".basename($_FILES['userimg']['name']) ;
		if (!file_exists("profile/". $user ."/"))
		{
			mkdir("profile/". $user ."/",0700,true);
		}
		$target = "profile/". $user ."/".basename($_FILES['userimg']['name']) ;
		
		$img_ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));
		$allow_ext=array("jpg","jpeg","png","gif");
		$img_name= pathinfo($name,PATHINFO_FILENAME)."_".time().".".$img_ext;
	    
		$base64_img=base64_encode(addslashes(file_get_contents($_FILES['userimg']['name'])));
		$img='base:image/'.$img_ext.';base,'.$base64_img;
		echo $img;
		if(in_array($img_ext,$allow_ext))
		{
			$sql2="select * from images where userid='$userid'";
			$query=mysqli_query($con,$sql2);
			$row1=mysqli_fetch_array($query);
			if($row1["name"])
			{
			$sql="update images set image='$img' where userid='$userid'";
			$result=mysqli_query($con,$sql);
			
			//move_uploaded_file($name,$target_dir);
			move_uploaded_file($_FILES['userimg']['tmp_name'],$target);
			}
			else 
			{
				$sql3="insert into images(image,userid) values('$img','$userid')";
				$result=mysqli_query($con,$sql3);
			
			//move_uploaded_file($name,$target_dir);
			move_uploaded_file($_FILES['userimg']['tmp_name'],$target);
			
			}
		}
		else
		{
			echo "Invalid image format";
		}
		
	}
	else
	{
		echo "No image selected";
	}
}
?>

<html>
<head>

    
</head>
<body>

<form method="post" action="" enctype='multipart/form-data'>
<img src="<?php echo $img_src;  ?>"> 
  <input type="file" class="text-center center-block file-upload" name="userimg">
		<button type="submit" class="btn" name="upload">Save</button>
</form>
</body>
<!--<script src="https://code.jquery.com/jquery-3.3.1.min.js"> </script> 
<script type="text/javascript"> 
        $(document).ready(function () { 
            $(".btn").click(function () { 
                $("#img").attr("src", "$img_src");
				alert("hlo");
            }); 
        }); 
    </script> -->
</html>
