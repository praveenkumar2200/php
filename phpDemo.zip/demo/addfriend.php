<?php 
include('image.php');

$userid=$_SESSION["ID"];
$user=$_SESSION["username"];

//-----friend request-------
/*if(isset($_GET['frnd_id']))
{
	echo $frnd_id=$_GET['frnd_id'];
	$req_sql="insert into user_friends(user_id,friend_id) values('$userid','$frnd_id')";
	$req_result=mysqli_query($con,$req_sql);
	if($req_result)
	{
		echo "sent successfully";

	}
}*/

//user profile image

$sql1="select * from images where userid='$userid' ";
$result1=mysqli_query($con,$sql1);
$row=mysqli_fetch_array($result1);

$userimage=$row["name"];
if(isset($userimage))
{
	  $img_src="profile/". $user ."/".$userimage;
}
else
{
	$img_src='upload/user.png';
}
?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
        <title>Friends List</title>
        <style>
            body {
                //margin-top: 20px;
                background: #eee;
            }
            /*==================================================
                   Nearby People CSS
             ==================================================*/
              .profile-cover {
                    width: 100%;
                }
                
                .profile-cover .cover {
                    position: relative;
                    border: 10px solid #FFF;
                }
                
                .profile-cover .cover .inner-cover {
                    overflow: hidden;
                    height: auto;
                }
                
                .profile-cover .cover .inner-cover img {
                    border: 1px solid transparent;
                    text-align: center;
                    width: 100%;
                }
                
                .profile-cover .cover .inner-cover .cover-menu-mobile {
                    position: absolute;
                    top: 10px;
                    right: 10px;
                }
                
                .profile-cover .cover .inner-cover .cover-menu-mobile button i {
                    font-size: 17px;
                }
                
                .profile-cover .cover ul.cover-menu {
                    padding-left: 150px;
                    position: absolute;
                    overflow: hidden;
                    left: 1px;
                    float: left;
                    bottom: 0px;
                    width: 100%;
                    margin: 0px;
                    background: none repeat scroll 0% 0% rgba(0, 0, 0, 0.24);
                }
                
                .profile-cover .cover ul.cover-menu li {
                    display: block;
                    float: left;
                    margin-right: 0px;
                    padding: 0px 10px;
                    line-height: 40px;
                    height: 40px;
                    -moz-transition: all 0.3s;
                    -o-transition: all 0.3s;
                    -webkit-transition: all 0.3s;
                    transition: all 0.3s;
                }
                
                .profile-cover .cover ul.cover-menu li:hover {
                    background-color: rgba(0, 0, 0, 0.44);
                }
                
                .profile-cover .cover ul.cover-menu li.active {
                    background-color: rgba(0, 0, 0, 0.64);
                }
                
                .profile-cover .cover ul.cover-menu li a {
                    color: #FFF;
                    font-weight: bold;
                    display: block;
                    height: 40px;
                    line-height: 40px;
                    text-decoration: none;
                }
                
                .profile-cover .cover ul.cover-menu li a i {
                    font-size: 18px;
                }
                
                .profile-cover .profile-body {
                    margin: 0px auto 10px;
                    position: relative;
                }
                
                .profile-cover .profile-timeline {
                    padding: 15px;
                }
                
                .img-post {
                    width: 30px;
                    height: 30px;
                }
                
                .img-post2 {
                    width: 50px;
                    height: 50px;
                }
                
			
			
			
            .people-nearby .google-maps {
                background: #f8f8f8;
                border-radius: 4px;
                border: 1px solid #f1f2f2;
                padding: 20px;
                margin-bottom: 20px;
            }
            
            .people-nearby .google-maps .map {
                height: 300px;
                width: 100%;
                border: none;
            }
            
            .people-nearby .nearby-user {
                padding: 10px 0;
                border-top: 1px solid #f1f2f2;
                border-bottom: 1px solid #f1f2f2;
                margin-bottom: 20px;
            }
            
            img.profile-photo-lg {
                height: 60px;
                width: 60px;
                border-radius: 50%;
            }
			
			.mar-del{
				    margin-right: 10px;
			}
        </style>
    </head>

    <body>
        <div class="container bootstrap snippets">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-4">
                    <div class="panel rounded shadow">
                        <div class="panel-body">
                            <div class="inner-all">
                                <ul class="list-unstyled">
                                    <li class="text-center">
                                        <img data-no-retina="" class="img-circle img-bordered-primary" src="<?php echo $img_src; ?>" alt="<?php echo $user; ?>" height="200px" width="200px">
                                    </li>
                                    <li class="text-center">
                                        <h4 class="text-capitalize"><?php echo $user; ?></h4>
                                        <p class="text-muted text-capitalize">web designer</p>
                                    </li>
                                    <li>
                                        <a href="" class="btn btn-success text-center btn-block">PRO Account</a>
                                    </li>
                                    <li>
                                        <br>
                                    </li>
                                    <li>
                                        <div class="btn-group-vertical btn-block">
                                            <a href="userprofile.php" class="btn btn-default"><i class="fa fa-cog pull-right"></i>Edit Account</a>
											 <a href="addfriend.php" class="btn btn-default"><i class="fas fa-user-check pull-right"></i>Friends</a>
                                            <a href="changepassword.php" class="btn btn-default"><i class="fa fa-lock pull-right"></i>Change Password</a>
                                            <!-- <a href="receiverequest.php" class="btn btn-default"><i class="fa fa-user-plus pull-right"></i>Friend Requests</a>-->
                                            <a href="logout.php" class="btn btn-default"><i class="fa fa-sign-out pull-right"></i>Logout</a>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- /.panel -->

                    <div class="panel panel-theme rounded shadow">
                        <div class="panel-heading">
                            <div class="pull-left">
                                <h3 class="panel-title">Contact</h3>
                            </div>
                            <div class="pull-right">
                                <a href="#" class="btn btn-sm btn-success"><i class="fa fa-facebook"></i></a>
                                <a href="#" class="btn btn-sm btn-success"><i class="fa fa-twitter"></i></a>
                                <a href="#" class="btn btn-sm btn-success"><i class="fa fa-google-plus"></i></a>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body no-padding rounded">
                            <ul class="list-group no-margin">
                                <li class="list-group-item"><i class="fa fa-envelope mr-5"></i> support@bootdey.com</li>
                                <li class="list-group-item"><i class="fa fa-globe mr-5"></i> www.bootdey.com</li>
                                <li class="list-group-item"><i class="fa fa-phone mr-5"></i> +6281 903 xxx xxx</li>
                            </ul>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->

                </div>
                <div class="col-lg-9 col-md-9 col-sm-8">
				  <div class="panel rounded shadow">
				   
					  <div class="container" style="max-width:100%;overflow-x:hidden;">
					  <h2>User Friends</h2>
					  <ul class="nav nav-tabs">
						<li class="active"><a data-toggle="tab" href="#home">Friends</a></li>
						 <li><a data-toggle="tab" href="#menu1">Find Friends</a></li>
						<li><a data-toggle="tab" href="#menu2">Receive Friend Requests</a></li>
					    <li><a data-toggle="tab" href="#menu3">View Sent Requests</a></li>
						
					  </ul>

					  <div class="tab-content">
						<div id="home" class="tab-pane fade in active">
						  <div class="container">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="people-nearby">
                    <?php 
					//======user friends list ======
					
					
					//====status=1 for frnd request sent,
					//==status=2 for request accept,
					//==status=3 for request delete and
                   //==status=4 for frnd request sent cancel
					
                    $sql="select * from users mu left outer join images mui on mui.userid=mu.id where mu.id<>'$userid' and  mu.id  in((select uf.friend_id from user_friends uf where uf.user_id='$userid' and uf.status in(2)) union (select uf.user_id from user_friends uf where uf.friend_id='$userid' and uf.status in(2)))";
                    $result=mysqli_query($con,$sql);
					while($row=mysqli_fetch_array($result))
					{
						$user_image="profile/".$row['username']."/".$row['name'];
						if($row['city']!="na"&&$row['state']!="na")
						{
						$user_address=$row['city'].",".$row['state'];
						}
						else
						{
							$user_address="";
						}
						//echo $row['id'];
					?>
                                        <div class="nearby-user">
                                            <div class="row">
											<form action="" method="post" id="reqForm">
                                                <div class="col-md-2 col-sm-2">
                                                    <img src="<?php echo $user_image; ?>" alt="" class="profile-photo-lg">
                                                </div>
                                                <div class="col-md-6 col-sm-6">
                                                    <h5><a href="#" class="profile-link"><?php echo $row['username']; ?></a></h5>
                                                    <p>
                                                    <?php echo $user_address; ?>
                                                    </p>

                                                </div>
                                                <div class="col-md-4 col-sm-4" style="margin-top:15px;">
                                                 
                                                        <button class="btn btn-primary pull-right" onclick="unFriend(<?php echo $row['id']?>)"> Friend</button>
                                                    
                                                </div>
												</form>
                                            </div>
											</div>
											<?php
											}	
											?>

                                </div>
                            </div>
                        </div>
                    </div>
						</div>
						<div id="menu1" class="tab-pane fade">
						<!--  <h3>Menu 1</h3>-->
                      <div class="container">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="people-nearby">
                    <?php 
					
					//=======find new friends======
					
                    $sql="select mu.id,mu.username,mu.city,mu.state,mui.id as image_id,mui.name from users mu left outer join images mui on mui.userid=mu.id where mu.id<>'$userid' and  mu.id  not in((select uf.friend_id from user_friends uf where uf.user_id='$userid' and uf.status in(1,2,3,4)) union (select uf.user_id from user_friends uf where uf.friend_id='$userid' and uf.status in(1,2,3,4))) and mu.id<>'$userid'";
                    $result=mysqli_query($con,$sql);
					while($row=mysqli_fetch_array($result))
					{
						$user_image="profile/".$row['username']."/".$row['name'];
						if($row['city']!="na"&&$row['state']!="na")
						{
						$user_address=$row['city'].",".$row['state'];
						}
						else
						{
							$user_address="";
						}
						//echo $row['id'];
					?>
                                        <div class="nearby-user">
                                            <div class="row">
											<form action="" method="post" id="reqForm">
                                                <div class="col-md-2 col-sm-2">
                                                    <img src="<?php echo $user_image; ?>" alt="" class="profile-photo-lg">
                                                </div>
                                                <div class="col-md-6 col-sm-6">
                                                    <h5><a href="#" class="profile-link"><?php echo $row['username']; ?></a></h5>
                                                    <p>
                                                    <?php echo $user_address; ?>
                                                    </p>

                                                </div>
                                                <div class="col-md-4 col-sm-4" style="margin-top:15px;">
                                                 
                                                        <button class="btn btn-primary pull-right" onclick="sendRequest(<?php echo $row['id']?>)">Add Friend</button>
                                                    
                                                </div>
												</form>
                                            </div>
											</div>
											<?php
											}	
											?>

                                </div>
                            </div>
                        </div>
                    </div>
						</div>
						<div id="menu2" class="tab-pane fade">
						      <div class="container">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="people-nearby">
                    <?php 
					//======Receive Friend requests sent by other users====
					$accept=2;
					$del=3;
                    $sql="select mu.id,mu.username,mu.city,mu.state,mui.id as image_id,mui.name from users mu left outer join images mui on mui.userid=mu.id where mu.id<>'$userid' and  mu.id  in((select uf.user_id from user_friends uf where uf.friend_id='$userid' and uf.status in(1)) union (select uf.user_id from user_friends uf where uf.friend_id='$userid' and uf.status in(1)))";
                    $result=mysqli_query($con,$sql);
					while($row=mysqli_fetch_array($result))
					{
						$user_image="profile/".$row['username']."/".$row['name'];
                        if($row['city']!="na" && $row['state']!="na")
						{
						$user_address=$row['city'].",".$row['state'];
						}
						else
						{
							$user_address="";
						}
					?>
                                        <div class="nearby-user">
                                            <div class="row">
											<form id="acceptForm" method="post">
                                                <div class="col-md-2 col-sm-2">
                                                    <img src="<?php echo $user_image; ?>" alt="" class="profile-photo-lg">
                                                </div>
                                                <div class="col-md-6 col-sm-6">
                                                    <h5><a href="#" class="profile-link"><?php echo $row['username']; ?></a></h5>
                                                    <p>
                                                    <?php echo $user_address; ?>
                                                    </p>
                                                    <input type="hidden" id="accept" value="<?php echo $accept; ?>">
													<input type="hidden" id="delete" value="<?php echo $del; ?>">
                                                </div>
                                                <div class="col-md-4 col-sm-4" style="margin-top:15px;">
                                                    
														<button class="btn pull-right" onclick="deleteRequest(<?php echo $row['id']?>)">Delete </button>
                                                        <button class="btn btn-primary pull-right mar-del" onclick="acceptRequest(<?php echo $row['id']?>)">Accept </button>
                                                   
                                                </div>
												</form>
                                            </div>
											</div>
											<?php
											}	
											?>

                                </div>
                            </div>
                        </div>
                    </div>
						</div>
						<div id="menu3" class="tab-pane fade">
						  	  <div class="container">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="people-nearby">
                    <?php 
					
					//====Friend Requests sent to other users====
					$cancel=4;
                    $sql="select mu.id,mu.username,mu.city,mu.state,mui.id as image_id,mui.name from users mu left outer join images mui on mui.userid=mu.id  where mu.id<>'$userid' and  mu.id  in((select uf.friend_id from user_friends uf where uf.user_id='$userid' and uf.status in(1)))";
                    $result=mysqli_query($con,$sql);
					while($row=mysqli_fetch_array($result))
					{
						$user_image="profile/".$row['username']."/".$row['name'];
						if($row['city']!="na"&&$row['state']!="na")
						{
						$user_address=$row['city'].",".$row['state'];
						}
						else
						{
							$user_address="";
						}
						//echo $row['id'];
					?>
                                        <div class="nearby-user">
                                            <div class="row">
											<form action="" method="post" id="cancelForm">
                                                <div class="col-md-2 col-sm-2">
                                                    <img src="<?php echo $user_image; ?>" alt="" class="profile-photo-lg">
                                                </div>
                                                <div class="col-md-5 col-sm-5">
                                                    <h5><a href="#" class="profile-link"><?php echo $row['username']; ?></a></h5>
                                                    <p>
													<input type="hidden" id="cancel" value="<?php echo $cancel; ?>">
                                                    <?php echo $user_address; ?>
                                                    </p>
                                                
                                                </div>
                                                <div class="col-md-5 col-sm-5" style="margin-top:15px;">
                                                    <button class="btn  pull-right" onclick="cancelRequest(<?php echo $row['id']?>)">Cancel</button>
                                                    <button class="btn btn-primary pull-right mar-del">Friend Request Sent</button>
                                                    
                                                </div>
												</form>
                                            </div>
											</div>
											<?php
											}	
											?>

                                </div>
                            </div>
                        </div>
                    </div>
						</div>
					  </div>
					</div>
									 
                  
                </div>
				 </div>
            </div>

    </body>
    <script>
	function sendRequest(frnd_id){
		$.post("sendrequest.php?frnd_id="+frnd_id+"",{
			
		},function(data){
			alert(data);
			$("#reqForm")[0].reset();
			locaton.reload();
			
		});
	}
	</script>
	<script>
	function acceptRequest(frnd_id){
		var status=$("#accept").val();
		$.post("acceptDelReq.php?frnd_id="+frnd_id+"",{
			status1:status
		},function(data){
			alert(data);
			$("#acceptForm")[0].reset();
			location.reload();
		});
	}
    </script>
    <script>
	function deleteRequest(frnd_id){
		var status=$("#delete").val();
		$.post("acceptDelReq.php?frnd_id="+frnd_id+"",{
			status1:status
		},function(data){
			alert(data);
			$("#acceptForm")[0].reset();
			location.reload();
		});
	}
    </script><script>
	function cancelRequest(frnd_id){
		var status=$("#cancel").val();
		$.post("cancelrequest.php?frnd_id="+frnd_id+"",{
			status1:status
		},function(data){
			alert(data);
			$("#cancelForm")[0].reset();
			location.reload();
		});
	}
    </script>

    </html>