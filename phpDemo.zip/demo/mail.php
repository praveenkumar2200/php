
<?php
include('image.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';


if(isset($_POST["send"]))
{
	$err="";
	$sender_email=$_POST["email"];
	$sender_pass=$_POST["password"];
	$recp_email=$_POST["to_id"];
	$sub=$_POST["subject"];
	$msg=$_POST["message"];
	$name=$_POST["name"];
	
	$mail=new PHPMailer(true);
	$mail->isSMTP();
	$mail->Mailer = "smtp";
	$mail->SMTPDebug  = 2; 
	$mail->host='ssl://smtp.gmail.com';
	$mail->port=587;
	$mail->SMTPSecure= 'tls';
	$mail->SMTPAuth=true;
	$mail->Username=$sender_email;
	$mail->Password=$sender_pass;
	$mail->SetFrom ($sender_email);
	$mail->FromName=$name;
	$mail->IsHTML(true);
	$mail->addAddress($recp_email);
	$mail->subject=$sub;
	$mail->MsgHTML($msg);
	
	if($mail->send())
	{
		$err="Email Sent";
	}
	else
	{
		$err="Mailer Error:".$mail->ErrorInfo;
	}
}

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Send email</title>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
<meta name="robots" content="noindex, nofollow">
<script type="text/javascript">
var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-43981329-1']);
_gaq.push(['_trackPageview']);
(function() {
var ga = document.createElement('script');
ga.type = 'text/javascript';
ga.async = true;
ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
var s = document.getElementsByTagName('script')[0];
s.parentNode.insertBefore(ga, s);
})();
</script>
<style>
@import url(http://fonts.googleapis.com/css?family=Raleway);

h1{
text-align:center;
//color: black;
font-size: 2em;
margin-top: 40px;
margin-bottom: 40px;
}

#main{
margin: 25px 100px;
font-family: 'Raleway', sans-serif;
}

h2{
background-color: #FEFFED;
text-align:center;
border-radius: 10px 10px 0 0;
margin: -10px -40px;
padding: 30px 40px;
color: black;
font-weight: bolder;
font-size: 1.5em;
margin-top: -1px !important;
// margin-bottom: -19px !important;
}

hr{
border:0;
border-bottom:1px solid #ccc;
margin: 10px -40px;
margin-bottom: 30px;
}

#login{
width:580px;
float: left;
border-radius: 10px;
font-family:raleway;
border: 2px solid #ccc;
padding: 0px 40px 0px;
margin-top: 70px;
//margin: 50px;
margin: 0% 33%;
}

input[type=text],input[type=email],input[type=password]{
width:99.5%;
padding: 10px;
margin-top: 8px;
border: 1px solid #ccc;
padding-left: 5px;
font-size: 16px;
font-family:raleway;
}

textarea{
width:99.5%;
padding: 10px;
margin-top: 8px;
border: 1px solid #ccc;
padding-left: 5px;
margin-bottom: 5px;
font-size: 16px;
font-family:raleway;
}

input[type=submit]{
width: 100%;
background-color:#FFBC00;
color: white;
border: 2px solid #FFCB00;
padding: 10px;
font-size:20px;
cursor:pointer;
border-radius: 5px;
margin-bottom: 40px;
}
#para{
clear: both;
margin: 0 35%;
}
</style>
</head>
<body>
<div id="main">
<h1>Send email via Gmail SMTP server in PHP</h1>
<div id="login">
<h2>Gmail SMTP</h2>
<hr/>
<form action="" method="post">
 <span style="color:red;"><?php if(isset($err)){ echo $err;} ?> </span>
 <input type="text" placeholder="Your Name " name="name"/>
<input type="text" placeholder="Enter your email ID" name="email" require/>
<input type="password" placeholder="Password" name="password"/>
<input type="text" placeholder="To : Email Id " name="to_id"/>
<input type="text" placeholder="Subject : " name="subject"/>
<textarea rows="4" cols="50" placeholder="Enter Your Message..." name="message"></textarea>
<input type="submit" value="Send" name="send"/>
</form>
</div>
</div>

</body>
</html>