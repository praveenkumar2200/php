<?php
session_start();
include("config.php");
 $userid=$_SESSION["ID"];
 $user=$_SESSION["username"];
 $frnd_id=$_GET['frnd_id'];
$status=$_POST["status1"];
	$req_sql="update user_friends set status='$status' where user_id='$frnd_id' and friend_id='$userid'";
	$req_result=mysqli_query($con,$req_sql);
	if($req_result)
	{
		if($status==2)
		{
		   echo "Friend Request Aceepted successfully";
		}
		else
		{
		   echo "Friend Request Deleted successfully";
		}
		
	}
?>