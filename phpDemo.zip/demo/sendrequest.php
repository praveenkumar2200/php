<?php
session_start();
include("config.php");
$userid=$_SESSION["ID"];
$user=$_SESSION["username"];
$frnd_id=$_GET['frnd_id'];
	$req_sql="insert into user_friends(user_id,friend_id) values('$userid','$frnd_id')";
	$req_result=mysqli_query($con,$req_sql);
	if($req_result)
	{
		echo "Friend Reqsest sent successfully";
	}
?>