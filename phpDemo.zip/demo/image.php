<?php
session_start();
include('config.php');
if(!isset($_SESSION["loggedin"])||$_SESSION["loggedin"]!=true)
{
	header("location:login.php");
	exit;
}
else
{
$user=$_SESSION["username"];	
}

//user profile image
/*$userid=$_SESSION["ID"];
$sql1="select * from images where userid='$userid' ";
$result1=mysqli_query($con,$sql1);
$row=mysqli_fetch_array($result1);

$userimage=$row["name"];
if(isset($userimage))
{
	  $img_src="profile/". $user ."/".$userimage;
}
else
{
	$img_src='upload/user.png';
}*/
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <style>    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">First Look</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="usertimeline.php">Home</a></li>
        <li><a href="userprofile.php">Setting</a></li>
		<li><a href="uploaddoc.php">Upload Documents</a></li>
		<li><a href="downloadfile.php">Download Documents</a></li>
      </ul>
      <form class="navbar-form navbar-right" role="search" action="" method="post">
        <div class="form-group input-group">
          <input type="text" class="form-control" placeholder="Search.." style="margin-top:0;">
          <span class="input-group-btn">
            <button class="btn btn-default" type="button" style="margin-top:0;">
              <span class="glyphicon glyphicon-search"></span>
            </button>
          </span>        
        </div>
      </form>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#">
		<span class="glyphicon glyphicon-user"></span>
		<?php echo htmlspecialchars($user); ?></a></li>
		
       <li><a href="logout.php"><span class="glyphicon "></span> Logout</a></li>
     
      </ul>
	  
    </div>
  </div>
</nav>
  


</body>
</html>
