<?php
require_once "config.php";

if(isset($_POST["submit"]))
{
	$user=$pass=$confirm_pass="";
	$user_err=$pass_err=$confirm_pass_err="";
	$user=trim($_POST["username"]);
	if(!empty($user))
	{
		$sql="select * from users where username='$user'";
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($result);
		if($row["username"]==$user)
		{
			$user_err= "Username Already Exist!";
		}
		else 
		{
			$pass=trim($_POST["psw"]);
			if(strlen($pass)<6)
			{
				$pass_err ="Password must have atleast 6 characters";
			}
			elseif($pass!=trim($_POST["confirm_psw"]))
			{
				$confirm_pass_err ="Password did not match!";
			}
			else
			{
				$pass_para=password_hash($pass,PASSWORD_DEFAULT);
				$sql1="insert into users(username,password) values('$user','$pass_para')";
				$query=mysqli_query($con,$sql1);
				if($query)
				{
					header("location: login.php");
				}
			}
		}
	}
}

?>




<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
form {border: 3px solid #f1f1f1;}

input[type=text], input[type=password] {
  /*width: 100%;*/
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0px 0px 146px;
  border: none;
  cursor: pointer;
 
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
</head>
<body style="width:500px;margin: 100px 189px 50px 449px;"">

<h2>Registration Form</h2>

<form action="" method="post">
  

  <div class="container">
    <label for="uname" style="margin-right:65px"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="username" required></br>
    <span style="color:red;margin-left:148px;"><?php if(isset($user_err)){ echo $user_err;} ?> </span></br>
	
    <label for="psw" style="margin-right:65px"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required></br>
    <span style="color:red;margin-left:148px;"><?php if(isset($pass_err)){ echo $pass_err;} ?> </span></br>
	
    <label for="psw"><b>Confirm Password</b></label>
    <input type="password" placeholder="Enter Password" name="confirm_psw" required></br>
	<span style="color:red;margin-left:148px;"><?php if(isset($confirm_pass_err)){ echo $confirm_pass_err;} ?> </span></br>
	
    <button type="submit" name="submit">Register</button></br>
    <label>
      Already have an account? &nbsp <a href="login.php">Login</a>
    </label>
  </div>

  
</form>

</body>
</html>
