<?php
//session_start();
include('image.php');
/*include('config.php');
if(!isset($_SESSION["loggedin"])|| $_SESSION["loggedin"]!=true)
{
	header("location:login.php");
	exit;
}*/
if(isset($_POST["submit"]))
{
	$oldpass=$newpass=$confirm_newpass="";
	$oldpass_err=$newpass_err=$confirm_newpass_err="";
	
	if(!empty(trim($_POST[oldpsw])))
	{
		$userid=$_SESSION["ID"];
		$sql="select * from users where id='$userid'";
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($result);
		$pass_hash=$row["password"];
		if(password_verify(trim($_POST[oldpsw]),$pass_hash))
		{
			$oldpass=trim($_POST[oldpsw]);
		}
		else
		{
			$oldpass_err="Incorrect password";
		}
	}
	else
	{
		$oldpass_err="Please enter old Password";
	}
	if(!empty(trim($_POST[newpsw]))&&!empty(trim($_POST[confirm_newpsw])))
	{
		$newpass=trim($_POST[newpsw]);
		if(strlen($newpass)<6)
		{
			$newpass_err="Password must have atleast 6 characters";
		}
		elseif($newpass!=trim($_POST[confirm_newpsw]))
		{
			$confirm_newpass_err="Password did not match";
		}
		else
		{
			$confirm_newpass=trim($_POST[confirm_newpsw]);
		}
	}
	else
	{
		
	}
	if(!empty($oldpass)&&!empty($newpass)&&!empty($confirm_newpass))
	{
		$hash_pass=password_hash($newpass,PASSWORD_DEFAULT);
		$sql1="update users set password='$hash_pass' where id='$userid'";
		$result1=mysqli_query($con,$sql1);
		if($result1)
		{
			$_SESSION="";
			session_destroy();
			header("location:login.php");
			exit;
		}
		mysqli_close($con);
	}
	else 
	{
		echo "Oops! Something went wrong.";
	}
}
?>


<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
form {border: 3px solid #f1f1f1;}

input[type=text], input[type=password] {
  /*width: 100%;*/
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0px 0px 146px;
  border: none;
  cursor: pointer;
 
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
</head>
<body>

<h2>Change Password Form</h2>

<form action="" method="post"  style="width:500px;">
  

  <div class="container">
    <label for="uname" style="margin-right:36px"><b>Old Password</b></label>
    <input type="password" placeholder="Enter Username" name="oldpsw" required></br>
    <span style="color:red;margin-left:148px;"><?php if(isset($oldpass_err)){ echo $oldpass_err;} ?> </span></br>
	
    <label for="psw" style="margin-right:28px"><b> New Password</b></label>
    <input type="password" placeholder="Enter Password" name="newpsw" required></br>
    <span style="color:red;margin-left:148px;"><?php if(isset($newpass_err)){ echo $newpass_err;} ?> </span></br>
	
    <label for="psw"><b>Confirm Password</b></label>
    <input type="password" placeholder="Enter Password" name="confirm_newpsw" required></br>
	<span style="color:red;margin-left:148px;"><?php if(isset($confirm_newpass_err)){ echo $confirm_newpass_err;} ?> </span></br>
	
    <button type="submit" name="submit">Confirm</button></br>
   <!-- <label>
      Already have an account? &nbsp <a href="login.php">Login</a>
    </label> -->
  </div>

  
</form>

</body>
</html>
