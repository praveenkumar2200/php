
<?php
//session_start();
include('image.php');
/*include('config.php');
if(!isset($_SESSION["loggedin"])||$_SESSION["loggedin"]!=true)
{
	header("location:login.php");
	exit;
}*/
$userid=$_SESSION["ID"];
$user=$_SESSION["username"];

$sql1="select * from images where userid=$userid ";
$result1=mysqli_query($con,$sql1);
$row=mysqli_fetch_array($result1);

$userimage=$row["name"];
//echo "upload/".$userimage."_".$userid."_".current_time();
if(isset($userimage))
{
	 $img_src="profile/". $user ."/".$userimage;
}
else
{
	$img_src='upload/user.png';
}


if(isset($_POST["upload"]))
{
	if(isset($_FILES['userimg']['name'])&&!empty($_FILES['userimg']['name']))
	{
		$img_ext=strtolower(pathinfo($_FILES['userimg']['name'],PATHINFO_EXTENSION));
		
		$name=pathinfo($_FILES['userimg']['name'],PATHINFO_FILENAME)."_".$userid."_".date('Y-m-d-H-m-s').".".$img_ext;
		//$target1 = "upload/".basename($_FILES['userimg']['name']) ;
		if (!file_exists("profile/". $user ."/"))
		{
			mkdir("profile/". $user ."/",0700,true);
		}
		//$target = "profile/". $user ."/".basename($_FILES['userimg']['name']) ;
		$target = "profile/". $user ."/".$name;
		
		$allow_ext=array("jpg","jpeg","png","gif");
		//$img_name= pathinfo($name,PATHINFO_FILENAME)."_".time().".".$img_ext;
	    echo $name;
		if(in_array($img_ext,$allow_ext))
		{
			$sql2="select * from images where userid='$userid'";
			$query=mysqli_query($con,$sql2);
			$row1=mysqli_fetch_array($query);
			if($row1["name"])
			{
			$sql="update images set name='$name' where userid='$userid'";
			$result=mysqli_query($con,$sql);
			
			//move_uploaded_file($name,$target_dir);
			move_uploaded_file($_FILES['userimg']['tmp_name'],$target);
			}
			else 
			{
				$sql3="insert into images(name,userid) values('$name','$userid')";
				$result=mysqli_query($con,$sql3);
			
			//move_uploaded_file($name,$target_dir);
			move_uploaded_file($_FILES['userimg']['tmp_name'],$target);
			
			}
		}
		else
		{
			echo "Invalid image format";
		}
		
	}
	else
	{
		echo "No image selected";
	}
}
?>

<html>
<head>
<style>    
   
	
	<!-- --------  opopup css-------- -->
	#myImg {
  border-radius: 5px;
  cursor: pointer;
  transition: 0.3s;
}

#myImg:hover {
	opacity: 0.7;
	text:Change Photo;
	}

/* The Modal (background) */
.modal {
	margin-top:50px;
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.1); /* Black w/ opacity */
}

/* Modal Content (image) */
.modal-content {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
}

/* Caption of Modal Image */
#caption {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
  text-align: center;
  color: #ccc;
  padding: 10px 0;
  height: 150px;
}

/* Add Animation */
.modal-content, #caption {  
  -webkit-animation-name: zoom;
  -webkit-animation-duration: 0.6s;
  animation-name: zoom;
  animation-duration: 0.6s;
}

@-webkit-keyframes zoom {
  from {-webkit-transform:scale(0)} 
  to {-webkit-transform:scale(1)}
}

@keyframes zoom {
  from {transform:scale(0)} 
  to {transform:scale(1)}
}

/* The Close Button */
.close1 {
  position: absolute;
  top: 15px;
  right: 35px;
  color:black;
  font-size: 40px;
  font-weight: bold;
  transition: 0.3s;
}

.close1:hover,
.close1:focus {
	color: red; 
  text-decoration: none;
  cursor: pointer;
  
 
}

/* 100% Image Width on Smaller Screens */
@media only screen and (max-width: 700px){
  .modal-content {
    width: 100%;
  }
}

<!-- --------new popup ----------- -->

	/*set styles for the cancel button*/ 
	.cancelbtn { 
		padding: 14px 20px; 
		background-color: #FF2E00; 
	} 
	/*float cancel and signup buttons and add an equal width*/ 
	.cancelbtn, 
	.signupbtn { 
		float: left; 
		width: 15% 
	} 
	/*add padding to container elements*/ 
	.container { 
		padding: 16px; 
	} 
	/*define the modal’s background*/ 
	
	
.clearfix::after { 
		content: ""; 
		clear: both; 
		display: table; 
	} 
	

<!---hover---->
 

	@media screen and (max-width: 300px) { 
		.cancelbtn, 
		.signupbtn { 
			width: 100%; 
		} 
	} 
  </style>
    
</head>
<body>
<div class="pic">
<img src="<?php echo $img_src;  ?>"  id="myImg"> 

  </div>
 <!-- <input type="file" class="text-center center-block file-upload" name="userimg">
		<button type="submit" class="btn" name="upload">Save</button> -->

<div id="myModal" class="modal">
  <span class="close1">&times;</span>
 <form class="modal-content animate" action="" method="post" enctype='multipart/form-data'> 
			<div class="container"> 
				<div>
				<img src="<?php echo $img_src;  ?>"  id="myImg"> 
				</div>
				</br>
               <div>
			   <input type="file" class="text-center  file-upload" name="userimg">
			   </div>
                
				<div class="clearfix"> 
					<button type="button" onclick="document.getElementById('myModal').style.display='none'" class="cancelbtn">Cancel</button> 
					<button type="submit" class="signupbtn" name="upload">Save</button> 
				</div> 
			</div> 
		</form> 
  <div id="caption"></div>
</div>

</body>
<script>
// Get the modal
var modal = document.getElementById("myModal");

// Get the image and insert it inside the modal - use its "alt" text as a caption
var img = document.getElementById("myImg");

img.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
  captionText.innerHTML = this.alt;
  
}

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close1")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() { 
  modal.style.display = "none";
}




</script>
<script>
<!--close the modal by just clicking outside of the modal-->
<!--
<script> 
		var modal = document.getElementById('myModal'); 

		window.onclick = function(event) { 
			if (event.target == modal) { 
				modal.style.display = "none"; 
			} 
		} 
	</script> -->
</html>
