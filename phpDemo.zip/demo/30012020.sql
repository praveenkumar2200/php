-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 30, 2020 at 01:02 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `blocked_post`
--

CREATE TABLE `blocked_post` (
  `id` int(11) NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `post_userid` int(11) DEFAULT NULL,
  `blockby_userid` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `createdat` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blocked_post`
--

INSERT INTO `blocked_post` (`id`, `post_id`, `post_userid`, `blockby_userid`, `status`, `createdat`) VALUES
(1, 20, 3, 2, 1, '2020-01-29 12:48:33');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `cmt_id` int(11) NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `cmt` varchar(1000) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `create_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`cmt_id`, `post_id`, `cmt`, `user_id`, `create_at`) VALUES
(1, 10, 'nice', 4, '2020-01-04 15:23:30'),
(2, 8, 'hello', 4, '2020-01-04 15:24:52'),
(3, 7, 'hii', 4, '2020-01-04 15:25:36'),
(7, 11, '', 1, '2020-01-04 15:40:10'),
(8, 11, 'hlo g', 1, '2020-01-04 15:40:23'),
(9, 11, '', 4, '2020-01-04 15:41:09'),
(10, 11, 'nice one', 4, '2020-01-04 15:47:17'),
(11, 10, 'nice', 4, '2020-01-04 15:51:15'),
(12, 10, 'nice', 4, '2020-01-04 15:51:20'),
(13, 9, 'hello bro', 4, '2020-01-04 17:02:03'),
(14, 9, 'yes bro', 1, '2020-01-04 17:02:29'),
(15, 9, 'how are you bro?', 2, '2020-01-04 17:12:14'),
(16, 8, 'hii', 1, '2020-01-06 10:50:01'),
(17, 12, 'hoo', 1, '2020-01-06 10:50:24'),
(18, 12, 'hii', 4, '2020-01-06 14:21:00'),
(19, 12, 'nice', 1, '2020-01-06 15:46:56'),
(20, 12, 'hii hlo', 1, '2020-01-06 16:01:28'),
(21, 12, 'nice one', 1, '2020-01-06 16:09:18'),
(22, 8, 'nice one', 1, '2020-01-06 18:03:10'),
(23, 12, 'hey guys', 5, '2020-01-07 10:25:12'),
(24, 13, 'hello bro', 5, '2020-01-07 11:28:51'),
(25, 11, 'nice', 4, '2020-01-07 16:16:38'),
(26, 11, 'nyc', 5, '2020-01-16 17:53:54'),
(27, 13, 'nyc', 4, '2020-01-17 10:24:06'),
(38, 17, 'okk', 2, '2020-01-21 15:17:40'),
(42, 17, 'nyc', 2, '2020-01-21 15:18:58'),
(59, 18, 'nycc one', 2, '2020-01-23 11:27:28'),
(65, 18, 'hey', 5, '2020-01-23 13:51:34'),
(66, 18, 'nycc', 5, '2020-01-23 14:09:20'),
(67, 18, 'hey', 5, '2020-01-24 11:32:28'),
(68, 16, 'nycc', 1, '2020-01-28 15:17:55'),
(69, 15, 'nycc', 1, '2020-01-28 15:32:26'),
(70, 14, 'hey', 1, '2020-01-28 15:39:16'),
(71, 16, 'hey', 1, '2020-01-28 16:03:21'),
(72, 7, 'hlo', 1, '2020-01-28 16:10:50'),
(73, 20, 'grtgrt', 2, '2020-01-29 15:04:36');

-- --------------------------------------------------------

--
-- Table structure for table `comment_reply`
--

CREATE TABLE `comment_reply` (
  `rep_id` int(11) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `post_id` int(11) DEFAULT NULL,
  `cmnt_id` int(11) DEFAULT NULL,
  `reply_userid` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `createdat` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comment_reply`
--

INSERT INTO `comment_reply` (`rep_id`, `description`, `user_id`, `post_id`, `cmnt_id`, `reply_userid`, `status`, `createdat`) VALUES
(1, 'hlo', 3, 20, 73, 5, 1, '2020-01-30 16:18:06'),
(2, 'how are you', 2, 18, 59, 5, 1, '2020-01-30 16:18:42'),
(3, 'hii', 3, 20, 73, 4, 1, '2020-01-30 16:25:30'),
(4, 'hlo', 2, 18, 66, 4, 1, '2020-01-30 16:25:47'),
(5, 'how are you', 5, 16, 71, 4, 1, '2020-01-30 16:25:58'),
(7, 'ghfg', 2, 18, 65, 5, 1, '2020-01-30 16:50:45'),
(8, 'hlo', 2, 18, 66, 5, 1, '2020-01-30 16:52:53'),
(9, 'right', 0, 20, 73, 6, 1, '2020-01-30 17:05:14');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `uploadedby` int(11) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `downloads` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `name`, `uploadedby`, `size`, `downloads`) VALUES
(1, 'cv-format.pdf', NULL, 230020, 0),
(2, 'cv-format.pdf', NULL, 230020, 1),
(3, 'Resume.docx', NULL, 29111, 0),
(4, 'Resume.docx', 2, 29111, 2),
(5, 'Resume_1577703487.docx', 2, 29111, 2),
(6, 'cv-format_1577703932.pdf', 1, 230020, 3),
(7, 'Resume_1577705268.docx', 1, 29111, 4),
(8, 'cv-format_1577703932_1577791867.pdf', 4, 2574, 0),
(9, 'PHPMailer-FE_v4.11_20191231121234.zip', 4, 98668, 2),
(10, 'Resume_20191231121211.docx', 4, 29111, 0),
(11, 'emplacement_20191231121247.zip', 5, 787447, 0),
(12, 'donkey-talk_20200106100136.zip', 1, 145171, 5),
(13, 'a_20200116130133.docx', 2, 12103, 1);

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `image` longtext NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `name`, `image`, `userid`) VALUES
(1, 'w3logo_1_2020-01-04-12-01-57.jpg', '', 1),
(3, 'Capture.PNG', '', 0),
(4, 'Capture.PNG', '', 0),
(6, 'ykp_2_2019-12-30-09-12-11.png', 'base:image/png;base,', 2),
(7, 'apture.PNG', '', 3),
(9, 'paris_4_2020-01-02-08-01-44.jpg', '', 4),
(10, 'photo_5_2020-01-16-13-01-12.jpg', '', 5),
(11, 'cloud_6_2020-01-27-11-01-21.jpg', '', 6);

-- --------------------------------------------------------

--
-- Table structure for table `post_likes`
--

CREATE TABLE `post_likes` (
  `like_id` int(11) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `post_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `post_likes`
--

INSERT INTO `post_likes` (`like_id`, `status`, `post_id`, `user_id`, `created`) VALUES
(1, 1, 12, 4, '2020-01-06 12:27:44'),
(2, 1, 12, 1, '2020-01-06 12:28:06'),
(3, 1, 8, 4, '2020-01-06 12:28:17'),
(4, 1, 11, 1, '2020-01-06 13:58:07'),
(6, 1, 11, 4, '2020-01-06 14:24:37'),
(7, 1, 10, 1, '2020-01-06 14:47:13'),
(8, 1, 7, 4, '2020-01-06 16:28:57'),
(9, 1, 6, 4, '2020-01-06 16:29:08'),
(10, 0, 9, 4, '2020-01-06 16:29:18'),
(11, 1, 12, 2, '2020-01-06 16:38:35'),
(12, 1, 11, 2, '2020-01-06 16:38:38'),
(13, 1, 12, 3, '2020-01-06 16:38:59'),
(14, 1, 11, 3, '2020-01-06 16:39:02'),
(15, 1, 9, 3, '2020-01-06 16:39:06'),
(16, 1, 8, 3, '2020-01-06 16:39:11'),
(17, 1, 7, 3, '2020-01-06 16:39:16'),
(18, 1, 7, 1, '2020-01-06 18:01:19'),
(19, 1, 9, 1, '2020-01-06 18:01:35'),
(20, 1, 6, 1, '2020-01-06 18:02:45'),
(21, 1, 8, 1, '2020-01-06 18:02:57'),
(22, 0, 12, 5, '2020-01-07 10:25:28'),
(23, 1, 11, 5, '2020-01-07 10:25:36'),
(24, 1, 10, 5, '2020-01-07 10:25:42'),
(25, 1, 13, 5, '2020-01-07 11:16:49'),
(26, 1, 13, 4, '2020-01-07 11:26:31'),
(27, 1, 13, 3, '2020-01-07 15:14:19'),
(28, 1, 10, 4, '2020-01-07 17:44:57'),
(29, 1, 9, 5, '2020-01-16 17:54:14'),
(30, 1, 8, 5, '2020-01-16 17:54:30'),
(31, 1, 17, 5, '2020-01-27 13:34:57'),
(32, 1, 16, 5, '2020-01-27 13:34:42'),
(33, 1, 15, 5, '2020-01-20 17:47:51'),
(34, 1, 14, 5, '2020-01-21 13:30:47'),
(35, 1, 16, 2, '2020-01-21 14:48:25'),
(36, 1, 0, 0, '2020-01-21 14:55:24'),
(37, 1, 17, 2, '2020-01-21 14:56:23'),
(38, 1, 18, 2, '2020-01-21 15:04:04'),
(39, 1, 15, 2, '2020-01-21 15:09:24'),
(41, 1, 7, 5, '2020-01-24 11:34:13'),
(42, 1, 6, 5, '2020-01-24 11:34:33'),
(44, 1, 18, 5, '2020-01-27 13:34:37'),
(45, 1, 18, 1, '2020-01-28 11:48:31'),
(46, 1, 16, 1, '2020-01-28 11:48:38'),
(47, 1, 18, 6, '2020-01-28 11:55:52'),
(48, 1, 16, 6, '2020-01-28 11:55:55'),
(49, 1, 20, 6, '2020-01-30 17:21:18');

-- --------------------------------------------------------

--
-- Table structure for table `timeline`
--

CREATE TABLE `timeline` (
  `id` int(11) NOT NULL,
  `text` varchar(1000) DEFAULT NULL,
  `imagename` varchar(200) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `createdat` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `timeline`
--

INSERT INTO `timeline` (`id`, `text`, `imagename`, `userid`, `status`, `createdat`) VALUES
(6, 'grgrt', '', 4, 1, '2020-01-03 16:58:20'),
(7, '', 'ykp_2_2019-12-30-09-12-11 (1)_1_20200103120152.png', 1, 1, '2020-01-03 17:11:52'),
(8, 'how are you', 'wall_4_20200103120120.jpg', 4, 1, '2020-01-03 17:13:20'),
(9, '', 'camera_1_20200103120147.png', 1, 1, '2020-01-03 17:13:47'),
(10, 'hello guys', 'paris_2_20200103120150.jpg', 2, 1, '2020-01-03 17:14:50'),
(11, 'Hello Guys.\r\nHow Are You?', 'w3logo_4_20200104070139.jpg', 4, 1, '2020-01-04 12:01:39'),
(12, 'Attention Guys!', 'bird_2_20200104120111.jpg', 2, 1, '2020-01-04 17:13:11'),
(13, 'Good Morning Frnds', 'images_5_20200107060116.jpg', 5, 1, '2020-01-07 11:05:16'),
(14, 'htyt', '', 4, 1, '2020-01-17 11:14:11'),
(15, 'How\'s that', 'photo_4_20200117060119.jpg', 4, 1, '2020-01-17 11:15:19'),
(16, 'niceee', 'Custom-Images_5_20200120070120.png', 5, 1, '2020-01-20 11:48:20'),
(17, '', 'lead_2_20200120070103.png', 2, 1, '2020-01-19 11:51:03'),
(18, 'heloo guys', '', 2, 1, '2020-01-21 14:56:44'),
(20, '', 'more_3_20200128130106.png', 3, 1, '2020-01-28 18:05:06');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `emailid` varchar(25) DEFAULT NULL,
  `firstname` varchar(20) DEFAULT NULL,
  `lastname` varchar(20) DEFAULT NULL,
  `mobileno` varchar(20) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `emailid`, `firstname`, `lastname`, `mobileno`, `address`, `city`, `state`, `created_at`) VALUES
(1, 'praveen', '$2y$10$oQ5OENK3WsXin2Gm6GFt/./0M5/6cjV5BKfAFESyxi.q252ktkWrC', 'praveen@gmail.com', 'praveen', 'khari', '986302145', 'xyz', 'noida', 'UP', '2019-12-25 11:46:48'),
(2, 'pkk', '$2y$10$ukNSjk9YqNcKixOYdOhkqOanhh59AgjDW1/p1f5cVDcYlmOeDDnh6', 'pkk@gmail.com', 'praveen', 'kumar', '9874563210', 'abc', 'noida', 'UP', '2019-12-26 15:06:06'),
(3, 'ppk', '$2y$10$sw5Ka8.NXmBvz/5/g3Jg4O01Wux9xTFl16FDh/OCeQ.0zccF4g3N6', 'ppk@gmail.com', 'prem Pratap', 'singh', '9856231470', 'abc', 'noida', 'UP', '2019-12-26 15:44:35'),
(4, 'yeskaypee', '$2y$10$iCS8kjSfekpE6nR7qoIaW.w/40SZBYQZ/QdnG19TlsHT3wS5v9HUG', 'ykp@gmail.com', 'ykp', '', '9856231047', 'as', 'noida', 'UP', '2019-12-31 16:57:07'),
(5, 'admin', '$2y$10$QsR.XflUYlRdQrXeoIoUYOJrZnDmbbjzTO0jzLCyev/BqhUYiCXi6', 'admin@gmail.com', 'Admin', 'admi', '9856231047', 'na', 'na', 'na', '2019-12-31 17:07:44'),
(6, 'user', '$2y$10$4zeujnJOQnjb2DpaMj/5MOT6dV4Eoy8CxaljmFm8T9Gb.zlKrBdk6', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-01-27 15:30:33');

-- --------------------------------------------------------

--
-- Table structure for table `user_friends`
--

CREATE TABLE `user_friends` (
  `req_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `friend_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `created` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_friends`
--

INSERT INTO `user_friends` (`req_id`, `user_id`, `friend_id`, `status`, `created`) VALUES
(1, 4, 3, 1, '2020-01-07 13:33:44'),
(2, 4, 1, 2, '2020-01-20 17:12:22'),
(4, 5, 4, 2, '2020-01-20 17:12:59'),
(10, 2, 5, 2, '2020-01-27 14:33:07'),
(11, 2, 4, 2, '2020-01-27 14:34:11'),
(13, 4, 6, 2, '2020-01-27 15:40:07'),
(15, 6, 5, 3, '2020-01-27 16:16:58'),
(16, 2, 6, 1, '2020-01-28 11:07:40'),
(17, 1, 2, 4, '2020-01-28 11:23:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blocked_post`
--
ALTER TABLE `blocked_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`cmt_id`);

--
-- Indexes for table `comment_reply`
--
ALTER TABLE `comment_reply`
  ADD PRIMARY KEY (`rep_id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD PRIMARY KEY (`like_id`);

--
-- Indexes for table `timeline`
--
ALTER TABLE `timeline`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `user_friends`
--
ALTER TABLE `user_friends`
  ADD PRIMARY KEY (`req_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blocked_post`
--
ALTER TABLE `blocked_post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `cmt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `comment_reply`
--
ALTER TABLE `comment_reply`
  MODIFY `rep_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `post_likes`
--
ALTER TABLE `post_likes`
  MODIFY `like_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `timeline`
--
ALTER TABLE `timeline`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_friends`
--
ALTER TABLE `user_friends`
  MODIFY `req_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
