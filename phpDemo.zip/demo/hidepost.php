<?php
session_start();
include("config.php");
 $userid=$_SESSION["ID"];
$postid=$_GET['post_id'];
    $post_userid=$_POST["post_userid1"];
    $hide_sql="select * from blocked_post where post_id='$postid' and blockby_userid='$userid'";
	$hide_result=mysqli_query($con,$hide_sql);
    $row=mysqli_fetch_array($hide_result);
	if(empty($row["post_id"]))
	{ 
        $sql="insert into blocked_post(post_id,post_userid,blockby_userid,status) values('$postid','$post_userid','$userid','1')";
		$result=mysqli_query($con,$sql);
		if($result)
		{
			echo "Post Hide successfully";
		}
       
	}
	/*else
	{
		 $status=0;
		date_default_timezone_set('Asia/Kolkata');      
        $date=date("Y-m-d H:i:s");
		$sql="update blocked_post set status='$status' , createdat='$date' where post_id='$postid' and blockby_userid='$userid'";
		$result=mysqli_query($con,$sql);
		if($result)
		{
			echo "Post Hide successfully";
		}
	}*/
?>