<?php
//session_start();
include('image.php');
/*include('config.php');
if(!isset($_SESSION["loggedin"])||$_SESSION["loggedin"]!=true)
{
	header("location:login.php");
	exit;
}*/
$userid=$_SESSION["ID"];
$user=$_SESSION["username"];

$sql1="select * from images where userid='$userid' ";
$result1=mysqli_query($con,$sql1);
$row=mysqli_fetch_array($result1);

$userimage=$row["name"];
if(isset($userimage))
{
	  $img_src="profile/". $user ."/".$userimage;
}
else
{
	$img_src='upload/user.png';
}

//-------Display data-------
$sql4="select * from users where id='$userid'";
$result4=mysqli_query($con,$sql4);
$row4=mysqli_fetch_array($result4);
if($row4)
{
	$firstname=$row4["firstname"];
	$lastname=$row4["lastname"];
	$email=$row4["emailid"];
	$mobileno=$row4["mobileno"];
	$address=$row4["address"];
	$city=$row4["city"];
	$state=$row4["state"];
}

if(isset($_POST["upload_img"]))
{
	if(isset($_FILES['userimg']['name'])&&!empty($_FILES['userimg']['name']))
	{
		$img_err='';
		//$name=$_FILES['userimg']['name'];
		$img_ext=strtolower(pathinfo($_FILES['userimg']['name'],PATHINFO_EXTENSION));
		$name=pathinfo($_FILES['userimg']['name'],PATHINFO_FILENAME)."_".$userid."_".date('Y-m-d-H-m-s').".".$img_ext;
		//$target_dir='upload/';
		//$target = "upload/".basename($_FILES['userimg']['name']) ;
		if (!file_exists("profile/". $user ."/"))
		{
			mkdir("profile/". $user ."/",0700,true);
		}
		$target = "profile/". $user ."/".$name ;
		
		//$img_ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));
		
		$allow_ext=array("jpg","jpeg","png","gif");
	   
		if(in_array($img_ext,$allow_ext))
		{
			$sql2="select * from images where userid='$userid'";
			$query=mysqli_query($con,$sql2);
			$row1=mysqli_fetch_array($query);
			if($row1["name"])
			{
			$sql="update images set name='$name' where userid='$userid'";
			$result=mysqli_query($con,$sql);
			
			//move_uploaded_file($name,$target_dir);
			move_uploaded_file($_FILES['userimg']['tmp_name'],$target);
			}
			else 
			{
				$sql3="insert into images(name,userid) values('$name','$userid')";
				$result=mysqli_query($con,$sql3);
			
			//move_uploaded_file($name,$target_dir);
			move_uploaded_file($_FILES['userimg']['tmp_name'],$target);
			}
		}
		else
		{
			$img_err= "Invalid image format";
		}
		
	}
	else
	{
		$img_err= "No image selected";
	}
}

if(isset($_POST["save"]))
{
	$error_msg='';
	$firstname=$_POST["first_name"];
	$lastname=$_POST["last_name"];
	$email=$_POST["email"];
	$mobileno=$_POST["mobile"];
	$address=$_POST["address"];
	$city=$_POST["city"];
	$state=$_POST["state"];
	$sql3="update users set firstname='$firstname',lastname='$lastname',emailid='$email',mobileno='$mobileno',address='$address',city='$city',state='$state' where id='$userid'";
	
	$result3=mysqli_query($con,$sql3);
	if($result3)
	{
		$error_msg="Saved Successfully.";
	}
	else
	{
		$error_msg="Oops!Something went wrong.";
	}
}
?>

<!DOCTYPE html>
<html>
<head>
<title>User Profile</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
<!--<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script 

<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->
<style>
<!-- --------  opopup css-------- -->


	#myImg {
  border-radius: 5px;
  cursor: pointer;
  transition: 0.3s;
}

#myImg:hover {
	opacity: 0.6;
	
	}

/* The Modal (background) */
.modal {
	margin-top:50px;
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.1); /* Black w/ opacity */
}

/* Modal Content (image) */
.modal-content {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 500px;
}

/* Caption of Modal Image */
#caption {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
  text-align: center;
  color: #ccc;
  padding: 10px 0;
  height: 150px;
}

/* Add Animation */
.modal-content, #caption {  
  -webkit-animation-name: zoom;
  -webkit-animation-duration: 0.6s;
  animation-name: zoom;
  animation-duration: 0.6s;
}

@-webkit-keyframes zoom {
  from {-webkit-transform:scale(0)} 
  to {-webkit-transform:scale(1)}
}

@keyframes zoom {
  from {transform:scale(0)} 
  to {transform:scale(1)}
}

/* The Close Button */
.close1 {
  position: absolute;
  top: 65px;
  right: 35%;
  color:black;
  font-size: 40px;
  font-weight: bold;
  transition: 0.3s;
}

.close1:hover,
.close1:focus {
	color: red; 
  text-decoration: none;
  cursor: pointer;
  
 
}

/* 100% Image Width on Smaller Screens */
@media only screen and (max-width: 700px){
  .modal-content {
    width: 100%;
  }
}

<!-- --------new popup ----------- -->

	/*set styles for the cancel button*/ 
	.cancelbtn { 
		padding: 14px 20px; 
		background-color: #FF2E00; 
	} 
	/*float cancel and signup buttons and add an equal width*/ 
	.cancelbtn, 
	.signupbtn { 
		float: left; 
		width: 15% 
	} 
	/*add padding to container elements*/ 
	.container { 
		padding: 16px; 
	} 
	/*define the modal’s background*/ 
	
	
.clearfix::after { 
		content: ""; 
		clear: both; 
		display: table; 
		
	} 

<!-- -------hover text------ -->

	.content_img{
    position: relative;
    
    float: left;
    margin-right: 10px;
}

/* Child Text Container */
.content_img div{
    position: absolute;
    top: 0;
    right: 46px;
    background: black;
    color: white;
    
    font-family: sans-serif;
    opacity: 0;
    visibility: hidden;
    -webkit-transition: visibility 0s, opacity 0.5s linear;  
    transition: visibility 0s, opacity 0.5s linear;
}

/* Hover on Parent Container */
.content_img:hover{
    cursor: pointer;
}    

.content_img:hover div{
    width: 150px;
    padding: 8px 15px;
    visibility: visible;
    opacity: 0.7;        
}

	@media screen and (max-width: 300px) { 
		.cancelbtn, 
		.signupbtn { 
			width: 100%; 
		} 
	} 
</style>
</head>
<body>
<div class="container bootstrap snippet">
    <div class="row">
  		<div class="col-sm-10"><h1>User Profile</h1></div>
    	<div class="col-sm-2"><a href="" class="pull-right"></a></div>
    </div>
    <div class="row">
  		<div class="col-sm-3"><!--left col-->
              
<form action="" method="post" enctype='multipart/form-data'>
      <div class="text-center">
	  <div class="content_img">
        <img src='<?php if(isset($img_src)){ echo $img_src;} else{ echo  "upload/are.PNG"; } ?>' class="avatar img-circle" alt="<?php echo $user; ?>" height="200px" width="200p">
		<div style="height:200px;width:200px;" id="myImg" class="avatar img-circle"><h3 style="margin-top:90px">Change Image</h3></div>
	  </div>
		<h3><?php echo $user; ?></h3>
        <div class="col-sm-10"></div>
     <!--<input type="file" class="text-center center-block file-upload" name="userimg">
		<button type="submit" class="" name="upload_img">Save</button> 
		</br>
		<span style="color:red;"><?php if(isset($img_err)){ echo $img_err;} ?> </span>
		<input type='submit' class="btn btn-lg btn-success" value='Save' name='upload' style="margin-top:15px;">-->
      </div></hr><br>
</form>
               
          <div class="panel panel-default">
            <div class="panel-heading">Website <i class="fa fa-link fa-1x"></i></div>
            <div class="panel-body"><a href="http://bootnipets.com">bootnipets.com</a></div>
          </div>
          
          
          <ul class="list-group">
            <li class="list-group-item text-muted">Activity <i class="fa fa-dashboard fa-1x"></i></li>
            <li class="list-group-item text-right"><span class="pull-left"><strong>Shares</strong></span> 125</li>
            <li class="list-group-item text-right"><span class="pull-left"><strong>Likes</strong></span> 13</li>
            <li class="list-group-item text-right"><span class="pull-left"><strong>Posts</strong></span> 37</li>
            <li class="list-group-item text-right"><span class="pull-left"><strong>Followers</strong></span> 78</li>
          </ul> 
               
          <div class="panel panel-default">
            <div class="panel-heading">Social Media</div>
            <div class="panel-body">
            	<i class="fa fa-facebook fa-2x"></i> <i class="fa fa-github fa-2x"></i> <i class="fa fa-twitter fa-2x"></i> <i class="fa fa-pinterest fa-2x"></i> <i class="fa fa-google-plus fa-2x"></i>
            </div>
          </div>
          
        </div><!--/col-3-->
    	<div class="col-sm-9">
            <ul class="nav nav-tabs">
                <li class="active"><a data-toggle="tab" href="#home">Personal Details</a></li>
                <li><a data-toggle="tab" href="#messages">Hobbies </a></li>
                <li><a data-toggle="tab" href="#settings">Social Media</a></li>
              </ul>

              
          <div class="tab-content">
            <div class="tab-pane active" id="home">
                <hr>
                  <form class="form" action="##" method="post" id="registrationForm">
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="first_name"><h4>First name</h4></label>
                              <input type="text" class="form-control" name="first_name" id="first_name" placeholder="first name" value="<?php echo $row4["firstname"]; ?>">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                            <label for="last_name"><h4>Last name</h4></label>
                              <input type="text" class="form-control" name="last_name" id="last_name" placeholder="last name" value="<?php echo $row4["lastname"]; ?>">
                          </div>
                      </div>
          
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="email"><h4>Email</h4></label>
                              <input type="email" class="form-control" name="email" id="email" placeholder="you@email.com" value="<?php echo $row4["emailid"]; ?>">
                          </div>
                      </div>
          
                      <div class="form-group">
                          <div class="col-xs-6">
                             <label for="mobile"><h4>Mobile</h4></label>
                              <input type="text" class="form-control" name="mobile" id="mobile" placeholder="enter mobile number" value="<?php echo $row4["mobileno"]; ?>">
                          </div>
                      </div>
                      <div class="form-group">
                          
                           <div class="col-xs-6">
                              <label for="email"><h4>Address</h4></label>
                              <input type="text" class="form-control" id="location" name="address" placeholder="somewhere" value="<?php echo $row4["address"]; ?>">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="email"><h4>City</h4></label>
                              <input type="text" class="form-control" id="location" placeholder="City" name="city" value="<?php echo $row4["city"]; ?>">
                          </div>
                      </div>
                   <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="password"><h4>State</h4></label>
                              <input type="text" class="form-control" name="state" id="password" placeholder="State" value="<?php echo $row4["state"]; ?>">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
						 
                           <!-- <label for="password2"><h4>Verify</h4></label>
                              <input type="password" class="form-control" name="password2" id="password2" placeholder="password2" title="enter your password2.">-->
                          </div>
                      </div> 
                      <div class="form-group">
                           <div class="col-xs-12">
                                <br>
								 <span style="color:red;"><?php if(isset($error_msg)){ echo $error_msg;} ?> </span>
								 <br>
                              	<button class="btn btn-lg btn-success" type="submit" name="save"><i class="glyphicon glyphicon-ok-sign"></i> Save</button>
                               	<button class="btn btn-lg" type="reset"><i class="glyphicon glyphicon-repeat"></i> Reset</button>
                            </div>
                      </div>
              	</form>
              
              <hr>
              
             </div><!--/tab-pane-->
             <div class="tab-pane" id="messages">
               
               <h2></h2>
               
               <hr>
                  <form class="form" action="##" method="post" id="registrationForm">
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="first_name"><h4>First name</h4></label>
                              <input type="text" class="form-control" name="first_name" id="first_name" placeholder="first name" title="enter your first name if any.">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                            <label for="last_name"><h4>Last name</h4></label>
                              <input type="text" class="form-control" name="last_name" id="last_name" placeholder="last name" title="enter your last name if any.">
                          </div>
                      </div>
          
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="phone"><h4>Phone</h4></label>
                              <input type="text" class="form-control" name="phone" id="phone" placeholder="enter phone" title="enter your phone number if any.">
                          </div>
                      </div>
          
                      <div class="form-group">
                          <div class="col-xs-6">
                             <label for="mobile"><h4>Mobile</h4></label>
                              <input type="text" class="form-control" name="mobile" id="mobile" placeholder="enter mobile number" title="enter your mobile number if any.">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="email"><h4>Email</h4></label>
                              <input type="email" class="form-control" name="email" id="email" placeholder="you@email.com" title="enter your email.">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="email"><h4>Location</h4></label>
                              <input type="email" class="form-control" id="location" placeholder="somewhere" title="enter a location">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="password"><h4>Password</h4></label>
                              <input type="password" class="form-control" name="password" id="password" placeholder="password" title="enter your password.">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                            <label for="password2"><h4>Verify</h4></label>
                              <input type="password" class="form-control" name="password2" id="password2" placeholder="password2" title="enter your password2.">
                          </div>
                      </div>
                      <div class="form-group">
                           <div class="col-xs-12">
                                <br>
                              	<button class="btn btn-lg btn-success" type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Save</button>
                               	<button class="btn btn-lg" type="reset"><i class="glyphicon glyphicon-repeat"></i> Reset</button>
                            </div>
                      </div>
              	</form>
               
             </div><!--/tab-pane-->
             <div class="tab-pane" id="settings">
            		
               	
                  <hr>
                  <form class="form" action="##" method="post" id="registrationForm">
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="first_name"><h4>First name</h4></label>
                              <input type="text" class="form-control" name="first_name" id="first_name" placeholder="first name" title="enter your first name if any.">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                            <label for="last_name"><h4>Last name</h4></label>
                              <input type="text" class="form-control" name="last_name" id="last_name" placeholder="last name" title="enter your last name if any.">
                          </div>
                      </div>
          
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="phone"><h4>Phone</h4></label>
                              <input type="text" class="form-control" name="phone" id="phone" placeholder="enter phone" title="enter your phone number if any.">
                          </div>
                      </div>
          
                      <div class="form-group">
                          <div class="col-xs-6">
                             <label for="mobile"><h4>Mobile</h4></label>
                              <input type="text" class="form-control" name="mobile" id="mobile" placeholder="enter mobile number" title="enter your mobile number if any.">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="email"><h4>Email</h4></label>
                              <input type="email" class="form-control" name="email" id="email" placeholder="you@email.com" title="enter your email.">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="email"><h4>Location</h4></label>
                              <input type="email" class="form-control" id="location" placeholder="somewhere" title="enter a location">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="password"><h4>Password</h4></label>
                              <input type="password" class="form-control" name="password" id="password" placeholder="password" title="enter your password.">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                            <label for="password2"><h4>Verify</h4></label>
                              <input type="password" class="form-control" name="password2" id="password2" placeholder="password2" title="enter your password2.">
                          </div>
                      </div>
                      <div class="form-group">
                           <div class="col-xs-12">
                                <br>
                              	<button class="btn btn-lg btn-success pull-right" type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Save</button>
                               	<!--<button class="btn btn-lg" type="reset"><i class="glyphicon glyphicon-repeat"></i> Reset</button>-->
                            </div>
                      </div>
              	</form>
              </div>
               
              </div><!--/tab-pane-->
          </div><!--/tab-content-->

        </div><!--/col-9-->
    </div>
	<div id="myModal" class="modal">
  <span class="close1">&times;</span>
 <form class="modal-content animate" action="" method="post" enctype='multipart/form-data'> 
			<div class="container"> 
				<div style="margin-left: 10%;">
				<img src="<?php echo $img_src;  ?>" class="avatar img-circle"  height="250px" width="250px">
				</div>
				</br>
				<span style="color:red;margin-left: 12%;"><?php if(isset($img_err)){ echo $img_err;} ?> </span>
               <div style="margin-left: 13%;margin-top:10px">
			   <input type="file" class="text-center  file-upload" name="userimg">
			   </div>
                
				<div class="clearfix" style="margin:25px 114px"> 
					<button type="button" onclick="document.getElementById('myModal').style.display='none'" class="btn btn-lg">Cancel</button> 
					<button type="submit" class="btn btn-lg btn-success" name="upload_img">Change Image</button> 
				</div> 
			</div> 
		</form> 
  <div id="caption"></div>
</div>
<script>
// Get the modal
var modal = document.getElementById("myModal");

// Get the image and insert it inside the modal - use its "alt" text as a caption
var img = document.getElementById("myImg");
var modalImg = document.getElementById("img01");
var captionText = document.getElementById("caption");
img.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
  captionText.innerHTML = this.alt;
}

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close1")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() { 
  modal.style.display = "none";
}



</script>
	<script>
	$(document).ready(function() {

    
    var readURL = function(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('.avatar').attr('src', e.target.result);
            }
    
            reader.readAsDataURL(input.files[0]);
        }
    }
    

    $(".file-upload").on('change', function(){
        readURL(this);
    });
});
	</script>
</body>
</html>