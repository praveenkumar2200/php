<?php 
if(isset($_POST["submit_button"]))
{
	echo $txt=$_POST["input_tag"];
	
	if($txt==1)
	{
	 echo "<script>";
   echo "a();";
   echo "</script>";	
	 '<script type="text/javascript">a();</script>';	
	}
	elseif($txt==2)
	{
			echo 2;
    echo "<script>b();</script>";
	}
	else
	{
			echo "rest";
		echo "<script>c();</script>";
	}
}
?>

<!doctype html>
<html>
<head>
    <title>Create custom alert with sweetAlert jQuery plugin</title>
    <link href="style.css" type="text/css" rel="stylesheet">
    <link href="sweetalert.css" type="text/css" rel="stylesheet">
    <script src="jquery-3.4.1.min.js" type="text/javascript"></script>
    <script src="sweetalert.min.js" type="text/javascript"></script>
    
   
</head>
<body>
<form id="from1" method="post">
   <input type="text"name="input_tag" />

    <input type="submit" name="submit_button" 
           value="Click here" />

  </form>
<table>
    <tr>
        <td>Title</td>
        <td><input type='text' value='Title text' id='title'></td>
    </tr>
    <tr>
        <td>Message</td>
        <td><input type='text' value='Your message' id='message'></td>
    </tr>
    <tr>
        <td colspan='2'><input type='button' value='Simple alert' id='but1'>&nbsp;
        <input type='button' value='Alert with title' id='but2'>&nbsp;
        <input type='button' value='Alert with image' id='but3'>&nbsp;
        <input type='button' value='With timer' id='but4'>
        </td>
    </tr>
</table>
 <script type='text/javascript'>
 function a(){
            
            swal('Title1','Your message1');
        };
 
 
    $( document ).ready(function() {

        // Message
        $("#but1").click(function(){
            var message = $("#message").val();
            if(message == ""){
            message  = "Your message";
            }
            swal('Title1','Your message1');
        });

        // With message and title
        $("#but2").click(function(){
            var message = $("#message").val();
            var title = $("#title").val();
            if(message == ""){
            message  = "Your message";
            }
            if(title == ""){
            title = "Your message";
            }
            swal(title,message);
        });

        // Show image
        $("#but3").click(function(){
            var message = $("#message").val();
            var title = $("#title").val();
            if(message == ""){
                message  = "Your message";
            }
            if(title == ""){
                title = "Your message";
            }
            swal({
            title: title,
            text: message,
            imageUrl: "logo.png"
            });
        });

        // Timer
        $("#but4").click(function(){
            var message = $("#message").val();
            var title = $("#title").val();
            if(message == ""){
                message  = "Your message";
            }
            if(title == ""){
                title = "Your message";
            }
            message += "(close after 2 seconds)";
            swal({
                title: title,
                text: message,
                timer: 2000,
                showConfirmButton: false
            });
        });
    });
    </script>
</body>
</html>
