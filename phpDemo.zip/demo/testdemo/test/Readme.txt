Author: Yogesh singh
Author URL: http://makitweb.com/
Author Email: yogesh@makitweb.com
Tutorial Link: http://makitweb.com/how-to-send-javascript-array-to-the-ajax-using-jquery-and-php/


######
1. Import the attached userinfo.sql file in your database.
2. Update database configuration in config.php
