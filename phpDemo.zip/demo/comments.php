<?php
session_start();
include("config.php");
$userid=$_SESSION["ID"];
$user=$_SESSION["username"];

if(isset($_GET["post_id"])&& $_GET['post_id'] !== '')
{

	$postid=$_GET["post_id"];
	//$postid=$_POST["post_id"];
	$cmt=$_POST["name1"];
    if($cmt!="")
	{
		$postsql="insert into comment(post_id,cmt,user_id) values('$postid','$cmt','$userid')";
		$postresult=mysqli_query($con,$postsql);
		if($postresult)
		{
			echo "successful";
		}
	}
}
